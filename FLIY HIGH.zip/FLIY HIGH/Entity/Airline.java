package Entity;

public class Airline {
    private String name;
    private String code;
    private String headquarters;

    public Airline(String name, String code, String headquarters) {
        this.name = name;
        this.code = code;
        this.headquarters = headquarters;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getHeadquarters() {
        return headquarters;
    }

    public void setHeadquarters(String headquarters) {
        this.headquarters = headquarters;
    }
}

