package GUI;
import javax.swing.*;  
import java.awt.event.*;  
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;


public class Sign implements ActionListener{  
    
	 JButton lgnBtn;
     JButton sign;
     JButton exBtn;
     JLabel lusn;
     JLabel lpass;
     JLabel Inum;
     JTextField uname;
     JTextField upass;
     JTextField unum;
	JFrame frame;
	
 
   public Sign(){  
	
		
        //create frame
		frame = new JFrame ("BD AIR");
        //construct components
		sign = new JButton("Register");
        lusn = new JLabel ("Username");
        lpass = new JLabel ("Password");
        Inum = new JLabel ("Number");
        uname = new JTextField ();
        upass = new JTextField ();
        unum = new JTextField ();
		

        
		

		
		//addActionListener
		sign.addActionListener(this);

        //add components
        frame.add (sign);
        frame.add (lusn);
        frame.add (lpass);
        frame.add (uname);
        frame.add (upass);
        frame.add (Inum);
        frame.add (unum);
		
 ImageIcon img = new ImageIcon("D:\\FLIY HIGH\\Image\\p4.jpg");
		 frame.setIconImage(img.getImage());

		JLabel background = new JLabel("",img,JLabel.CENTER);
		
        background.setVerticalAlignment(JLabel.CENTER);
		background.setHorizontalAlignment(JLabel.CENTER);

		frame.add(background);
		frame.pack();
		
		//frame properties
		//adjust size and set layout
        //frame.setSize (624, 400);		//set component bounds (only needed by Absolute Positioning)
        sign.setBounds (950, 450, 100, 30);
        
        uname.setBounds (900, 300, 100, 25);
        unum.setBounds (900, 400, 100, 25);
        upass.setBounds (900, 350, 100, 25);
		 lusn.setBounds (800,300, 100, 25);
        lpass.setBounds (800, 350, 100, 25);
        Inum.setBounds (800, 400, 100, 25);
	
		sign.setFont(new Font("Comic sans",Font.PLAIN,15));
		sign.setBackground(Color.decode("#95CADB"));
	    sign.setFocusable(false);
		frame.setLocationRelativeTo(null);//to center screen gui
        frame.setLayout (null);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane();
        frame.setVisible (true); 
    }        
	
	

    public void actionPerformed(ActionEvent e) { 
	if(e.getSource()==sign){
	String t1 = uname.getText(); // User Name
                String t2 = upass.getText(); // Email
                String t3 = unum.getText(); // Password
             
         try {
                       File file = new File("D:\\FLIY HIGH\\Txtfiles\\registration.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                           

                            pw.println("Name : " +t1);
                            pw.println( "pass : " +t2);
                            pw.println("number : " +t3);
             
                            pw.close();

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }

                      
			
					showMessageDialog(null, "You registration is successful!","BD AIR",JOptionPane.PLAIN_MESSAGE);
	new Login();
	frame.setVisible(false);}
	
}}
   
 /* if(e.getSource()==sign)
			{
          		String user = uname.getText();
			String pass = upass.getText();
			String num = unum.getText();
			try{
FileWriter ft= new FileWriter("D:\\spring-24\\java\\Customer.txt");
ft.write( user + "\n");
ft.write( pass + "\n");
ft.write( num + "\n");
			ft.close();}
			catch(Exception b){}
		

				
				new Login();
			frame.setVisible(false);}
				
}}*/