#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <sstream>
#include <iomanip>
#include <cstdlib>
#include <cmath>

const int WIDTH = 1280;
const int HEIGHT = 720;

// ─── Global State ───────────────────────────────────────────────────────────
float camAngle = -5.0f;
float camPitch = 0.15f;
float camDist = 100.0f;
bool isMousePressed = false;
double lastMouseX = 0.0;
double lastMouseY = 0.0;
float timeOfDay = 0.33f;
float timeSpeed = 4000.0f;
float manualFog = 0.3f;
float manualWind = 0.25f;
float stormChangeSpeed = 0.5f;
float snowCoverage = 0.0f;
float lastFrame = 0.0f;

glm::vec3 planePos(0.0f, 20.0f, 0.0f);
float planeYaw = 0.0f;
bool showPlane = true;
bool showBirds = true;
bool heavyRainMode = false;
bool showAurora = false;
bool showShootingStars = false;
bool showHotAirBalloons = false;

struct Plane {
    GLuint VAO;
    GLuint VBO;
    int count;
};

enum WeatherType { CLEAR = 0, CLOUDY = 1, RAIN = 2, STORM = 3, FOG = 4, SNOW = 5 };
WeatherType currentWeather = CLEAR;

struct WeatherParams {
    float clouds;
    float fog;
    float rain;
    float snow;
};

WeatherParams weatherTarget = {0.05f, 0.1f, 0.0f, 0.0f};
WeatherParams weatherCurrent = weatherTarget;

// ─── Shader Compilation ────────────────────────────────────────────────────
GLuint compileShader(const char* source, GLenum type) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, NULL);
    glCompileShader(shader);
    GLint success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        char infoLog[1024];
        glGetShaderInfoLog(shader, 1024, NULL, infoLog);
        std::cerr << "Shader compilation error: " << infoLog << std::endl;
    }
    return shader;
}

GLuint createProgram(const char* vertexSrc, const char* fragmentSrc) {
    GLuint vs = compileShader(vertexSrc, GL_VERTEX_SHADER);
    GLuint fs = compileShader(fragmentSrc, GL_FRAGMENT_SHADER);
    GLuint program = glCreateProgram();
    glAttachShader(program, vs);
    glAttachShader(program, fs);
    glLinkProgram(program);
    GLint success;
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success) {
        char infoLog[1024];
        glGetProgramInfoLog(program, 1024, NULL, infoLog);
        std::cerr << "Program linking error: " << infoLog << std::endl;
    }
    glDeleteShader(vs);
    glDeleteShader(fs);
    return program;
}

// ─── Shader Source Code ────────────────────────────────────────────────────
const char* terrainVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNorm;
layout (location = 2) in vec2 aUV;
uniform mat4 uMVP;
uniform mat4 uModel;
out vec3 vWorldPos;
out vec3 vNorm;
out vec2 vUV;
float getTerrainHeight(float x, float z, float rawY) {
    float h = (sin(x * 0.2) + cos(z * 0.2)) * 0.5;
    float lakeMask = smoothstep(0.0, 20.0, x);
    float targetHeight = -0.8;
    return mix(h, targetHeight, lakeMask);
}
void main() {
    vec3 pos = aPos;
    pos.y = getTerrainHeight(pos.x, pos.z, aPos.y);
    vec4 wp = uModel * vec4(pos, 1.0);
    vWorldPos = wp.xyz;
    vNorm = mat3(uModel) * aNorm;
    vUV = aUV;
    gl_Position = uMVP * vec4(pos, 1.0);
}
)";

const char* terrainFS = R"(
#version 330 core
in vec3 vWorldPos;
in vec3 vNorm;
in vec2 vUV;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uAmbient;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform vec3 uCamPos;
out vec4 FragColor;
float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1, 0));
    float c = hash(i + vec2(0, 1));
    float d = hash(i + vec2(1, 1));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
void main() {
    vec3 N = normalize(vNorm);
    float h = vWorldPos.y;
    vec3 rock = vec3(0.45, 0.42, 0.38);
    vec3 dirt = vec3(0.38, 0.28, 0.18);
    vec3 grass = vec3(0.22, 0.42, 0.14);
    vec3 snow = vec3(0.92, 0.93, 0.97);
    float nv = noise(vUV * 8.0);
    vec3 col = mix(dirt, grass, smoothstep(-0.5, 0.5, h));
    col = mix(col, rock, smoothstep(2.0, 4.0, h) + (1.0 - N.y) * 0.5);
    col = mix(col, snow, smoothstep(5.0, 8.0, h));
    col *= 0.85 + 0.3 * nv;
    float diff = max(dot(N, normalize(uSunDir)), 0.0);
    float spec = pow(max(dot(reflect(-normalize(uSunDir), N), normalize(uCamPos - vWorldPos)), 0.0), 12.0) * 0.15;
    vec3 lit = uAmbient * col + diff * uSunColor * col + spec * uSunColor;
    float dist = length(vWorldPos - uCamPos);
    float fog = 1.0 - exp(-uFogDensity * dist * 0.015);
    fog = clamp(fog, 0.0, 1.0);
    FragColor = vec4(mix(lit, uFogColor, fog), 1.0);
}
)";

const char* sunVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
uniform mat4 uMVP;
out vec2 vTexCoord;
void main() {
    gl_Position = uMVP * vec4(aPos, 1.0);
    vTexCoord = aPos.xy;
}
)";

const char* sunFS = R"(
#version 330 core
in vec2 vTexCoord;
out vec4 FragColor;
uniform vec3 uColor;
void main() {
    float dist = length(vTexCoord);
    if (dist > 1.0) discard;
    float alpha = 1.0 - smoothstep(0.8, 1.0, dist);
    FragColor = vec4(uColor, alpha);
}
)";

const char* treeVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNorm;
layout (location = 2) in float aTreeID;
uniform mat4 uVP;
uniform float uTime;
uniform float uWind;
uniform float uWindSpeed;
out vec3 vNorm;
out float vHeight;
out float vTreeID;
void main() {
    float phase = aTreeID * 6.283 + uTime * uWindSpeed;
    float sway = sin(phase) * uWind * 0.04 * max(aPos.y - 1.5, 0.0);
    vec3 p = aPos;
    p.x += sway;
    p.z += cos(phase * 0.7) * uWind * 0.02 * max(aPos.y - 1.5, 0.0);
    vNorm = aNorm;
    vHeight = aPos.y;
    vTreeID = aTreeID;
    gl_Position = uVP * vec4(p, 1.0);
}
)";

const char* treeFS = R"(
#version 330 core
in vec3 vNorm;
in float vHeight;
in float vTreeID;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uAmbient;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform vec3 uCamPos;
uniform float uTime;
uniform float uSnowFactor;
out vec4 FragColor;
float hash(float n) {
    return fract(sin(n * 13.23) * 43758.5453);
}
void main() {
    vec3 N = normalize(vNorm);
    float t = hash(vTreeID);
    vec3 leafBase = vec3(0.12 + t * 0.08, 0.35 + t * 0.15, 0.08 + t * 0.06);
    vec3 bark = vec3(0.28, 0.20, 0.13);
    float isBark = step(vHeight, 1.8);
    vec3 baseCol = mix(leafBase, bark, isBark);
    vec3 snowColor = vec3(0.9, 0.92, 1.0);
    float snowAccumulation = smoothstep(0.1, 0.9, N.y) * smoothstep(1.5, 4.0, vHeight);
    vec3 finalCol = mix(baseCol, snowColor, snowAccumulation * uSnowFactor);
    float diff = max(dot(N, normalize(uSunDir)), 0.0) * 0.9;
    vec3 lit = uAmbient * finalCol + diff * uSunColor * finalCol;
    float dist = length(vec3(0.0, vHeight, 0.0) - uCamPos);
    float fog = 1.0 - exp(-uFogDensity * dist * 0.018);
    FragColor = vec4(mix(lit, uFogColor, clamp(fog, 0.0, 1.0)), 1.0);
}
)";

const char* skyVS = R"(
#version 330 core
layout (location = 0) in vec2 aPos;
out vec2 vUV;
void main() {
    vUV = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.999, 1.0);
}
)";

const char* skyFS = R"(
#version 330 core
in vec2 vUV;
uniform vec3 uZenith;
uniform vec3 uHorizon;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uTime;
uniform float uClouds;
out vec4 FragColor;
float hash(vec2 p) {
    vec3 p3  = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
void main() {
    float elev = vUV.y;
    vec3 sky = mix(uHorizon, uZenith, pow(elev, 0.6));
    float nightFactor = smoothstep(-0.08, -0.25, uSunDir.y);
    float starSeed = hash(floor(vUV * 600.0));
    float skyMask = smoothstep(0.1, 0.3, elev);
    float starIntensity = step(0.992, starSeed) * nightFactor * skyMask;
    sky += vec3(starIntensity * 3.0);
    vec3 moonDir = -uSunDir;
    float aspect = 1280.0 / 720.0;
    vec2 uvCorr = vUV;
    uvCorr.x *= aspect;
    vec2 moonPos = vec2(0.5 + moonDir.x * 0.4, 0.2 + moonDir.y * 0.6);//moon
    moonPos.x *= aspect;
    float moonDist = length(uvCorr - moonPos);
    float mainCircle = smoothstep(0.03, 0.028, moonDist);
    float shadowDist = length(uvCorr - (moonPos + vec2(0.012, 0.008)));
    float shadowCircle = smoothstep(0.03, 0.028, shadowDist);
    float crescent = clamp(mainCircle - shadowCircle, 0.0, 1.0) * nightFactor;
    float craters = hash(floor(uvCorr * 150.0)) * 0.3 + 0.7;
    vec3 moonCol = vec3(0.85, 0.9, 1.0);
    float moonGlow = exp(-moonDist * 25.0) * 0.3 * nightFactor;
    sky = mix(sky, moonCol * craters, crescent);
    sky += moonCol * moonGlow;
    vec2 sunUV = vUV - vec2(0.5 + uSunDir.x * 0.4, 0.2 + uSunDir.y * 0.6);
    float sunDist = length(sunUV);
    float sunGlow = exp(-sunDist * sunDist * 120.0) * 0.9 * max(uSunDir.y, 0.0);
    sky += uSunColor * sunGlow;
    FragColor = vec4(sky, 1.0);
}
)";

const char* particleVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in float aLife;
layout (location = 2) in float aType;
uniform mat4 uVP;
out float vLife;
out float vType;
void main() {
    vLife = aLife;
    vType = aType;
    gl_Position = uVP * vec4(aPos, 1.0);
    gl_PointSize = mix(2.0, 6.0, aType) * (vLife + 0.3);
}
)";

const char* particleFS = R"(
#version 330 core
in float vLife;
in float vType;
out vec4 FragColor;
void main() {
    vec2 uv = gl_PointCoord * 2.0 - 1.0;
    float d = dot(uv, uv);
    if (d > 1.0) discard;
    float a = vLife * (1.0 - d * 0.5);
    vec3 c = mix(vec3(0.6, 0.7, 0.9), vec3(0.92, 0.93, 0.97), vType);
    FragColor = vec4(c, a * 0.85);
}
)";

const char* waterVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
uniform mat4 uMVP;
uniform float uTime;
out float vHeight;
out vec3 vWorldPos;
void main() {
    vec3 pos = aPos;
    float s = 0.5 * sin(pos.x * 0.5 + uTime * 2.0) + 0.5 * cos(pos.z * 0.5 + uTime * 1.5);
    pos.y += s * 0.2;
    vHeight = s;
    vWorldPos = aPos;
    gl_Position = uMVP * vec4(pos, 1.0);
}
)";

const char* waterFS = R"(
#version 330 core
in float vHeight;
in vec3 vWorldPos;
out vec4 FragColor;
uniform float uTime;
uniform vec3 uSunDir;
float hash(vec2 p) {
    vec3 p3  = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
void main() {
    float nightFactor = smoothstep(-0.08, -0.25, uSunDir.y);
    vec3 shallowBlue = vec3(0.0, 0.4, 0.7);
    vec3 deepBlue = vec3(0.0, 0.1, 0.3);
    vec3 waterBase = mix(deepBlue, shallowBlue, vHeight + 0.5);
    vec3 nightAmbient = vec3(0.02, 0.05, 0.1) * nightFactor;
    waterBase += nightAmbient;
    vec2 starUV = vWorldPos.xz * 0.1;
    float starSeed = hash(floor(starUV * 600.0));
    float reflectionStars = step(0.992, starSeed) * nightFactor;
    vec3 finalColor = waterBase + (vec3(reflectionStars) * 2.5);
    finalColor += (vHeight * 0.05);
    FragColor = vec4(finalColor, 0.8);
}
)";

const char* mountainVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNorm;
uniform mat4 uMVP;
uniform mat4 uModel;
out vec3 vWorldPos;
out vec3 vNorm;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p);
    f = f*f*(3.0-2.0*f);
    return mix(mix(hash(i), hash(i+vec2(1,0)), f.x), mix(hash(i+vec2(0,1)), hash(i+vec2(1,1)), f.x), f.y);
}
void main() {
    vec3 pos = aPos;
    float h = noise(pos.xz * 0.05) * 40.0;
    h += noise(pos.xz * 0.1) * 15.0;
    pos.y = h - 5.0;
    vWorldPos = (uModel * vec4(pos, 1.0)).xyz;
    vNorm = aNorm;
    gl_Position = uMVP * vec4(pos, 1.0);
}
)";

const char* auroraVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec2 aTex;
uniform mat4 uMVP;
uniform float uTime;
uniform float uLayerOffset;
out vec2 vTex;
out float vRay;
void main() {
    vec3 pos = aPos;
    float strength = aTex.y;
    float curve = sin(pos.x * 0.005 + uLayerOffset) * 40.0;
    pos.z += curve;
    vRay = 0.5 + 0.5 * sin(pos.x * 3.0 + uTime * 0.5 + uLayerOffset);
    pos.z += sin(pos.x * 0.04 + uTime * 0.8) * 8.0 * strength;
    pos.x += cos(uTime * 0.4 + uLayerOffset) * 5.0 * strength;
    vTex = aTex;
    gl_Position = uMVP * vec4(pos, 1.0);
}
)";

const char* auroraFS = R"(
#version 330 core
in vec2 vTex;
in float vRay;
out vec4 FragColor;
uniform float uAlpha;
void main() {
    vec3 green = vec3(0.0, 1.0, 0.4);
    vec3 purple = vec3(0.4, 0.1, 0.8);
    vec3 finalColor = mix(green, purple, vTex.y * 0.8);
    float verticalShape = smoothstep(0.0, 0.1, vTex.y) * exp(-vTex.y * 3.5);
    float rayEffect = smoothstep(0.4, 0.9, vRay);
    FragColor = vec4(finalColor, uAlpha * verticalShape * (0.5 + 0.5 * rayEffect));
}
)";

const char* simpleVS = R"(
    #version 330 core
    layout (location = 0) in vec3 aPos;
    uniform mat4 uMVP;
    out vec3 vPos;
    void main() {
        vPos = aPos;
        gl_Position = uMVP * vec4(aPos, 1.0);
    }
)";

const char* simpleFS = R"(
    #version 330 core
    in vec3 vPos;
    out vec4 fragColor;
    uniform vec3 uColor;
    uniform int uUseMixedColor;
    uniform float uTime;
    uniform bool uIsNight;
    void main() {
        if (uUseMixedColor == 1) {
            vec3 colorA = vec3(1.0, 1.0, 1.0);
            vec3 colorB = vec3(0.0, 0.2, 0.5);
            float brightness = uIsNight ? 0.2 : 1.0;
            colorA *= brightness;
            colorB *= brightness;
            float mixer = clamp(vPos.z * 0.5 + 0.5, 0.0, 1.0);
            vec3 finalColor = mix(colorA, colorB, mixer);
            if (abs(vPos.x) > 1.0) {
                finalColor = mix(finalColor, vec3(0.8, 0.0, 0.0) * brightness, 0.5);
            }
            if (uIsNight) {
                if (vPos.x < -1.8) {
                    finalColor = vec3(1.0, 0.0, 0.0);
                } else if (vPos.x > 1.8) {
                    finalColor = vec3(0.0, 1.0, 0.0);
                }
                float strobe = step(0.9, fract(uTime * 1.25));
                if (abs(vPos.x) < 0.1 && abs(vPos.z) < 0.1 && strobe > 0.5) {
                    finalColor = vec3(1.0, 1.0, 1.0);
                }
            }
            fragColor = vec4(finalColor, 1.0);
        } else {
            fragColor = vec4(uColor, 1.0);
        }
    }
)";

const char* weatherVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
uniform mat4 uMVP;
uniform float uTime;
uniform float uSpeed;
void main() {
    vec3 pos = aPos;
    float height = 100.0;
    pos.y = mod(aPos.y - (uTime * uSpeed), height);
    if(uSpeed < 20.0) {
        pos.x += sin(uTime + aPos.y) * 2.0;
    }
    gl_Position = uMVP * vec4(pos, 1.0);
}
)";

const char* weatherFS = R"(
#version 330 core
out vec4 FragColor;
uniform vec3 uColor;
void main() {
    FragColor = vec4(uColor, 0.8);
}
)";

const char* grassVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aOffset;
uniform mat4 uVP;
uniform float uTime;
uniform float uWindForce;
out float vHeight;
void main() {
    vec3 pos = aPos;
    float swayX = sin(uTime * 2.0 + aOffset.x * 0.5) * (0.3 + uWindForce);
    float swayZ = cos(uTime * 1.5 + aOffset.z * 0.5) * (0.2 + uWindForce);
    pos.x += swayX * aPos.y;
    pos.z += swayZ * aPos.y;
    vec3 worldPos = pos + aOffset;
    vHeight = aPos.y;
    gl_Position = uVP * vec4(worldPos, 1.0);
}
)";

const char* grassFS = R"(
#version 330 core
in float vHeight;
out vec4 FragColor;
uniform bool uIsNight;
void main() {
    vec3 rootColor = vec3(0.05, 0.2, 0.05);
    vec3 tipColor = vec3(0.2, 0.6, 0.1);
    vec3 baseColor = mix(rootColor, tipColor, vHeight * 1.5);
    if (uIsNight) {
        baseColor *= vec3(0.2, 0.4, 0.6);
    }
    FragColor = vec4(baseColor, 1.0);
}
)";

const char* fireflyVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
uniform mat4 uVP;
uniform float uSize;
void main() {
    gl_Position = uVP * vec4(aPos, 1.0);
    gl_PointSize = uSize;
}
)";

const char* fireflyFS = R"(
#version 330 core
out vec4 FragColor;
uniform float uTime;
uniform vec3 uAmbient;
void main() {
    float pulse = 0.6 + 0.4 * sin(uTime * 4.0);
    vec3 spiritColor = vec3(0.7, 1.0, 0.3);
    vec3 finalColor = spiritColor * pulse + (uAmbient * 0.2);
    FragColor = vec4(finalColor, 1.0);
}
)";

// ─── NEW: Shooting Star Shaders ────────────────────────────────────────────
const char* shootingStarVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
uniform mat4 uVP;
void main() {
    gl_Position = uVP * vec4(aPos, 1.0);
}
)";

const char* shootingStarFS = R"(
#version 330 core
out vec4 FragColor;
uniform vec3 uColor;
uniform float uAlpha;
void main() {
    FragColor = vec4(uColor, uAlpha);
}
)";

// ─── NEW: Hot Air Balloon Shaders ──────────────────────────────────────────
const char* balloonVS = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
uniform mat4 uMVP;
out vec3 vPos;
void main() {
    vPos = aPos;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
)";

const char* balloonFS = R"(
#version 330 core
in vec3 vPos;
out vec4 FragColor;
uniform vec3 uColor;
uniform vec3 uColor2;
void main() {
    // Stripe pattern based on angle around Y axis
    float angle = atan(vPos.x, vPos.z);
    float stripe = step(0.5, fract(angle / 1.047 + 0.5)); // ~6 stripes (pi/3 each)
    vec3 col = mix(uColor, uColor2, stripe);
    FragColor = vec4(col, 1.0);
}
)";

// ─── Noise Functions ───────────────────────────────────────────────────────
float hash2(float x, float y) {
    return fabs(sin(x * 127.1f + y * 311.7f) * 43758.5453f);
}

float noise2(float x, float y) {
    float ix = floor(x), iy = floor(y);
    float fx = x - ix, fy = y - iy;
    float ux = fx * fx * (3.0f - 2.0f * fx);
    float uy = fy * fy * (3.0f - 2.0f * fy);
    float h00 = hash2(ix, iy);
    float h10 = hash2(ix + 1, iy);
    float h01 = hash2(ix, iy + 1);
    float h11 = hash2(ix + 1, iy + 1);
    h00 = fmod(h00, 1.0f);
    h10 = fmod(h10, 1.0f);
    h01 = fmod(h01, 1.0f);
    h11 = fmod(h11, 1.0f);
    return h00 * (1 - ux) * (1 - uy) +
           h10 * ux * (1 - uy) +
           h01 * (1 - ux) * uy +
           h11 * ux * uy;
}

float fbm(float x, float y) {
    return noise2(x, y) * 0.5f +
           noise2(x * 2, y * 2) * 0.25f +
           noise2(x * 4, y * 4) * 0.125f +
           noise2(x * 8, y * 8) * 0.0625f;
}

float terrainHeight(float x, float z) {
    float h = (sin(x * 0.2) + cos(z * 0.2)) * 2.0;
    float lakeMask = glm::smoothstep(5.0f, 20.0f, x);
    float targetHeight = -1.2f;
    return glm::mix(h, targetHeight, lakeMask);
}

// ─── Terrain Generation ────────────────────────────────────────────────────
struct Terrain {
    std::vector<float> vertices;
    std::vector<float> normals;
    std::vector<float> uvs;
    std::vector<unsigned int> indices;
    GLuint VAO, VBO_pos, VBO_norm, VBO_uv, EBO;
    int indexCount;
};

void generateTerrain(Terrain& terrain) {
    const float TSIZE = 80.0f;
    const float TSTEP = 2.0f;
    const int tcols = (int)(TSIZE / TSTEP) + 1;
    const int trows = (int)(TSIZE / TSTEP) + 1;
    for (int iz = 0; iz < trows; iz++) {
        for (int ix = 0; ix < tcols; ix++) {
            float x = (ix / (float)(tcols - 1) - 0.5f) * TSIZE;
            float z = (iz / (float)(trows - 1) - 0.5f) * TSIZE;
            float y = terrainHeight(x, z);
            terrain.vertices.push_back(x);
            terrain.vertices.push_back(y);
            terrain.vertices.push_back(z);
            terrain.uvs.push_back(ix / (float)tcols);
            terrain.uvs.push_back(iz / (float)trows);
            const float eps = 0.5f;
            float ny_nx = terrainHeight(x + eps, z) - terrainHeight(x - eps, z);
            float ny_nz = terrainHeight(x, z + eps) - terrainHeight(x, z - eps);
            glm::vec3 n(-ny_nx, 2 * eps, -ny_nz);
            n = glm::normalize(n);
            terrain.normals.push_back(n.x);
            terrain.normals.push_back(n.y);
            terrain.normals.push_back(n.z);
        }
    }
    for (int iz = 0; iz < trows - 1; iz++) {
        for (int ix = 0; ix < tcols - 1; ix++) {
            unsigned int a = iz * tcols + ix;
            terrain.indices.push_back(a);
            terrain.indices.push_back(a + 1);
            terrain.indices.push_back(a + tcols);
            terrain.indices.push_back(a + 1);
            terrain.indices.push_back(a + tcols + 1);
            terrain.indices.push_back(a + tcols);
        }
    }
    terrain.indexCount = terrain.indices.size();
    glGenVertexArrays(1, &terrain.VAO);
    glGenBuffers(1, &terrain.VBO_pos);
    glGenBuffers(1, &terrain.VBO_norm);
    glGenBuffers(1, &terrain.VBO_uv);
    glGenBuffers(1, &terrain.EBO);
    glBindVertexArray(terrain.VAO);
    glBindBuffer(GL_ARRAY_BUFFER, terrain.VBO_pos);
    glBufferData(GL_ARRAY_BUFFER, terrain.vertices.size() * sizeof(float), terrain.vertices.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, terrain.VBO_norm);
    glBufferData(GL_ARRAY_BUFFER, terrain.normals.size() * sizeof(float), terrain.normals.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(1);
    glBindBuffer(GL_ARRAY_BUFFER, terrain.VBO_uv);
    glBufferData(GL_ARRAY_BUFFER, terrain.uvs.size() * sizeof(float), terrain.uvs.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, terrain.EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, terrain.indices.size() * sizeof(unsigned int), terrain.indices.data(), GL_STATIC_DRAW);
    glBindVertexArray(0);
}

// ─── Forest/Tree Generation ────────────────────────────────────────────────
struct Forest {
    std::vector<float> vertices;
    std::vector<float> normals;
    std::vector<float> treeIDs;
    GLuint VAO, VBO_pos, VBO_norm, VBO_id;
    int vertexCount;
};

void addCylinder(Forest& forest, float x, float y, float z, float r, float h, int segs, float treeID) {
    for (int i = 0; i < segs; i++) {
        float a0 = (i / (float)segs) * 2.0f * M_PI;
        float a1 = ((i + 1) / (float)segs) * 2.0f * M_PI;
        float x0 = cos(a0) * r, z0 = sin(a0) * r;
        float x1 = cos(a1) * r, z1 = sin(a1) * r;
        forest.vertices.push_back(x + x0); forest.vertices.push_back(y); forest.vertices.push_back(z + z0);
        forest.vertices.push_back(x + x1); forest.vertices.push_back(y); forest.vertices.push_back(z + z1);
        forest.vertices.push_back(x + x0); forest.vertices.push_back(y + h); forest.vertices.push_back(z + z0);
        forest.normals.push_back(x0 / r); forest.normals.push_back(0); forest.normals.push_back(z0 / r);
        forest.normals.push_back(x1 / r); forest.normals.push_back(0); forest.normals.push_back(z1 / r);
        forest.normals.push_back(x0 / r); forest.normals.push_back(0); forest.normals.push_back(z0 / r);
        forest.treeIDs.push_back(treeID);
        forest.treeIDs.push_back(treeID);
        forest.treeIDs.push_back(treeID);
        forest.vertices.push_back(x + x1); forest.vertices.push_back(y); forest.vertices.push_back(z + z1);
        forest.vertices.push_back(x + x1); forest.vertices.push_back(y + h); forest.vertices.push_back(z + z1);
        forest.vertices.push_back(x + x0); forest.vertices.push_back(y + h); forest.vertices.push_back(z + z0);
        forest.normals.push_back(x1 / r); forest.normals.push_back(0); forest.normals.push_back(z1 / r);
        forest.normals.push_back(x1 / r); forest.normals.push_back(0); forest.normals.push_back(z1 / r);
        forest.normals.push_back(x0 / r); forest.normals.push_back(0); forest.normals.push_back(z0 / r);
        forest.treeIDs.push_back(treeID);
        forest.treeIDs.push_back(treeID);
        forest.treeIDs.push_back(treeID);
    }
}

void addCone(Forest& forest, float x, float y, float z, float r, float h, int segs, float treeID) {
    for (int i = 0; i < segs; i++) {
        float a0 = (i / (float)segs) * 2.0f * M_PI;
        float a1 = ((i + 1) / (float)segs) * 2.0f * M_PI;
        float x0 = cos(a0) * r;
        float z0 = sin(a0) * r;
        float x1 = cos(a1) * r;
        float z1 = sin(a1) * r;
        forest.vertices.push_back(x); forest.vertices.push_back(y + h); forest.vertices.push_back(z);
        forest.vertices.push_back(x + x0); forest.vertices.push_back(y); forest.vertices.push_back(z + z0);
        forest.vertices.push_back(x + x1); forest.vertices.push_back(y); forest.vertices.push_back(z + z1);
        glm::vec3 n(0, r / sqrt(r * r + h * h), 0);
        forest.normals.push_back(n.x); forest.normals.push_back(n.y); forest.normals.push_back(n.z);
        forest.normals.push_back(n.x); forest.normals.push_back(n.y); forest.normals.push_back(n.z);
        forest.normals.push_back(n.x); forest.normals.push_back(n.y); forest.normals.push_back(n.z);
        forest.treeIDs.push_back(treeID);
        forest.treeIDs.push_back(treeID);
        forest.treeIDs.push_back(treeID);
    }
}

void generateForest(Forest& forest) {
    const int NTREES = 5500;
    for (int i = 0; i < NTREES; i++) {
        float hx = hash2(i * 3.1f, i * 7.7f);
        float hz = hash2(i * 2.3f, i * 5.1f);
        hx = fmod(hx, 1.0f);
        hz = fmod(hz, 1.0f);
        float tx = (hx - 0.5f) * 500.0f;
        float tz = (hz - 0.6f) * 430.0f;
        if (tx > 4.0f) continue;
        float ty = terrainHeight(tx, tz);
        float scale = 1.0f + fmod(hash2(i, i * 2), 1.0f) * 1.5f;
        float bh = 1.5f * scale;
        float br = 0.15f * scale;
        addCylinder(forest, tx, ty, tz, br, bh, 6, (float)i);
        int layers = 3 + (int)(fmod(hash2(i * 4, i), 1.0f) * 2);
        for (int L = 0; L < layers; L++) {
            float lr = (1.2f - L * 0.25f) * scale;
            float lh = (1.8f + L * 0.6f) * scale;
            float ly = bh + L * 0.8f * scale;
            addCone(forest, tx, ty + ly, tz, lr, lh, 8, (float)i);
        }
    }
    forest.vertexCount = forest.vertices.size() / 3;
    glGenVertexArrays(1, &forest.VAO);
    glGenBuffers(1, &forest.VBO_pos);
    glGenBuffers(1, &forest.VBO_norm);
    glGenBuffers(1, &forest.VBO_id);
    glBindVertexArray(forest.VAO);
    glBindBuffer(GL_ARRAY_BUFFER, forest.VBO_pos);
    glBufferData(GL_ARRAY_BUFFER, forest.vertices.size() * sizeof(float), forest.vertices.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, forest.VBO_norm);
    glBufferData(GL_ARRAY_BUFFER, forest.normals.size() * sizeof(float), forest.normals.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(1);
    glBindBuffer(GL_ARRAY_BUFFER, forest.VBO_id);
    glBufferData(GL_ARRAY_BUFFER, forest.treeIDs.size() * sizeof(float), forest.treeIDs.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(2);
    glBindVertexArray(0);
}

GLuint progFirefly;
GLuint sunVAO, sunVBO;

void initSun() {
    float sunVertices[] = {
        -1.0f,  1.0f, 0.0f,
        -1.0f, -1.0f, 0.0f,
         1.0f, -1.0f, 0.0f,
        -1.0f,  1.0f, 0.0f,
         1.0f, -1.0f, 0.0f,
         1.0f,  1.0f, 0.0f
    };
    glGenVertexArrays(1, &sunVAO);
    glGenBuffers(1, &sunVBO);
    glBindVertexArray(sunVAO);
    glBindBuffer(GL_ARRAY_BUFFER, sunVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(sunVertices), sunVertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
}

// ─── Grass Generation (Instanced) ───────────────────────────────────────────
GLuint grassVAO, grassVBO_vertices, grassVBO_offsets;
int numGrassBlades = 10000;
bool showGrass = false;

void initGrass() {
    float bladeVertices[] = {
        -0.05f, 0.0f, 0.0f,
         0.05f, 0.0f, 0.0f,
         0.0f,  0.5f, 0.0f
    };
    std::vector<glm::vec3> offsets;
    float terrainScale = 5.0f;
    for(int i = 0; i < numGrassBlades; i++) {
        float x = (float)(rand() % 70) - 30.0f;
        float z = (float)(rand() % 70) - 30.0f;
        if (x > 5.0f) continue;
        float y = terrainHeight(x, z);
        offsets.push_back(glm::vec3(x * terrainScale, y, z * terrainScale));
    }
    numGrassBlades = (int)offsets.size();
    int actualGrassCount = numGrassBlades;
    glGenVertexArrays(1, &grassVAO);
    glBindVertexArray(grassVAO);
    glGenBuffers(1, &grassVBO_vertices);
    glBindBuffer(GL_ARRAY_BUFFER, grassVBO_vertices);
    glBufferData(GL_ARRAY_BUFFER, sizeof(bladeVertices), bladeVertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glGenBuffers(1, &grassVBO_offsets);
    glBindBuffer(GL_ARRAY_BUFFER, grassVBO_offsets);
    glBufferData(GL_ARRAY_BUFFER, actualGrassCount * sizeof(glm::vec3), offsets.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glVertexAttribDivisor(1, 1);
    glBindVertexArray(0);
}

struct FireflySystem {
    static const int COUNT = 100;
    std::vector<glm::vec3> positions;
    GLuint VAO, VBO;
    void init() {
        positions.resize(COUNT);
        for (int i = 0; i < COUNT; i++) resetFirefly(i);
        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO);
        glBindVertexArray(VAO);
        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glBufferData(GL_ARRAY_BUFFER, COUNT * sizeof(glm::vec3), positions.data(), GL_DYNAMIC_DRAW);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);
    }
    void resetFirefly(int i) {
        float x = (rand() % 200) - 100.0f;
        float z = (rand() % 200) - 100.0f;
        float ground = terrainHeight(x, z);
        positions[i] = glm::vec3(x, ground + 1.0f + (rand() % 5), z);
    }
    void update(float dt) {
        for (int i = 0; i < COUNT; i++) {
            positions[i].x += ((rand() % 100) / 100.0f - 0.5f) * 0.1f;
            positions[i].y += ((rand() % 100) / 100.0f - 0.5f) * 0.05f;
            positions[i].z += ((rand() % 100) / 100.0f - 0.5f) * 0.1f;
            float ground = terrainHeight(positions[i].x, positions[i].z);
            if (positions[i].y < ground + 0.5f) positions[i].y = ground + 0.6f;
            if (positions[i].y > ground + 10.0f) positions[i].y = ground + 9.5f;
        }
        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glBufferSubData(GL_ARRAY_BUFFER, 0, COUNT * sizeof(glm::vec3), positions.data());
    }
};

// ─── Particle System ───────────────────────────────────────────────────────
struct ParticleSystem {
    static const int NPART = 5000;
    std::vector<glm::vec3> positions;
    std::vector<glm::vec3> points;
    std::vector<float> lifetimes;
    std::vector<float> types;
    GLuint VAO, VBO_pos, VBO_life, VBO_type;
    GLuint progWeather = createProgram(weatherVS, weatherFS);
    GLuint weatherVAO, weatherVBO;

    void init(float wx, float wz) {
        positions.resize(NPART);
        lifetimes.resize(NPART);
        types.resize(NPART);
        for (int i = 0; i < NPART; i++) {
            float x = (float)(rand() % 400) - 200.0f;
            float y = (float)(rand() % 100);
            float z = (float)(rand() % 400) - 200.0f;
            positions[i] = glm::vec3(x, y, z);
            lifetimes[i] = (float)(rand() % 100) / 100.0f;
            types[i] = (i < NPART / 2) ? 0.0f : 1.0f;
        }
        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO_pos);
        glGenBuffers(1, &VBO_life);
        glGenBuffers(1, &VBO_type);
        glBindVertexArray(VAO);
        glBindBuffer(GL_ARRAY_BUFFER, VBO_pos);
        glBufferData(GL_ARRAY_BUFFER, positions.size() * sizeof(glm::vec3), positions.data(), GL_STATIC_DRAW);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), (void*)0);
        glEnableVertexAttribArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, VBO_life);
        glBufferData(GL_ARRAY_BUFFER, lifetimes.size() * sizeof(float), lifetimes.data(), GL_STATIC_DRAW);
        glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE, sizeof(float), (void*)0);
        glEnableVertexAttribArray(1);
        glBindBuffer(GL_ARRAY_BUFFER, VBO_type);
        glBufferData(GL_ARRAY_BUFFER, types.size() * sizeof(float), types.data(), GL_STATIC_DRAW);
        glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, sizeof(float), (void*)0);
        glEnableVertexAttribArray(2);
        glBindVertexArray(0);
    }

    void resetParticle(int i, float wx, float wz) {
        const float spread = 150.0f;
        positions[i].x = ((float)rand() / RAND_MAX - 0.5f) * spread + wx;
        positions[i].y = 30.0f + ((float)rand() / RAND_MAX) * 5.0f;
        positions[i].z = ((float)rand() / RAND_MAX - 0.5f) * spread + wz;
        lifetimes[i] = (float)rand() / RAND_MAX;
        types[i] = 0.0f;
    }

    void update(float dt, WeatherParams& weather, float wind, glm::vec3 camPos, const glm::mat4& VP) {
        bool isRaining = weather.rain > 0.05f;
        bool isSnowing = weather.snow > 0.05f;
        if (isRaining || isSnowing) {
            glEnable(GL_BLEND);
            glUseProgram(progWeather);
            float speed = isRaining ? 120.0f : 15.0f;
            glm::vec3 color = isRaining ? glm::vec3(0.6, 0.7, 1.0) : glm::vec3(1.0, 1.0, 1.0);
            glUniform1f(glGetUniformLocation(progWeather, "uTime"), (float)glfwGetTime());
            glUniform1f(glGetUniformLocation(progWeather, "uSpeed"), speed);
            glUniform3fv(glGetUniformLocation(progWeather, "uColor"), 1, glm::value_ptr(color));
            glUniformMatrix4fv(glGetUniformLocation(progWeather, "uMVP"), 1, GL_FALSE, glm::value_ptr(VP));
            glBindVertexArray(VAO);
            glPointSize(isSnowing ? 3.0f : 3.0f);
            glDrawArrays(GL_POINTS, 0, NPART);
            glDisable(GL_BLEND);
        }
        float rainSpeed = isSnowing ? 4.0f : 90.0f;
        float windForce = wind * 5.0f;
        for (int i = 0; i < NPART; i++) {
            types[i] = isSnowing ? 1.0f : 0.0f;
            positions[i].y -= dt * rainSpeed;
            positions[i].x += dt * windForce;
            lifetimes[i] -= dt * 0.5f;
            float groundHeight = terrainHeight(positions[i].x, positions[i].z);
            if (lifetimes[i] <= 0.0f || positions[i].y < groundHeight) {
                resetParticle(i, camPos.x, camPos.z);
                positions[i].y = camPos.y + 40.0f + ((float)rand() / RAND_MAX) * 10.0f;
            }
        }
    }

    void updateGPU() {
        glBindBuffer(GL_ARRAY_BUFFER, VBO_pos);
        glBufferSubData(GL_ARRAY_BUFFER, 0, NPART * sizeof(glm::vec3), positions.data());
        glBindBuffer(GL_ARRAY_BUFFER, VBO_life);
        glBufferSubData(GL_ARRAY_BUFFER, 0, NPART * sizeof(float), lifetimes.data());
        glBindBuffer(GL_ARRAY_BUFFER, VBO_type);
        glBufferSubData(GL_ARRAY_BUFFER, 0, NPART * sizeof(float), types.data());
    }

    void render(GLuint program, glm::mat4 VP) {
        glUseProgram(program);
        glBindVertexArray(VAO);
        GLint loc = glGetUniformLocation(program, "uVP");
        glUniformMatrix4fv(loc, 1, GL_FALSE, glm::value_ptr(VP));
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        glDrawArrays(GL_POINTS, 0, NPART);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }
};

// ─── Sky Colors ────────────────────────────────────────────────────────────
struct SkyColors {
    glm::vec3 zenith;
    glm::vec3 horizon;
    glm::vec3 sunColor;
    glm::vec3 ambient;
};

SkyColors getSkyColors(float tod) {
    float hour = tod * 24.0f;
    SkyColors sc;
    auto lerp3 = [](glm::vec3 a, glm::vec3 b, float t) { return glm::mix(a, b, t); };
    if (hour < 5.0f || hour > 22.0f) {
        sc.zenith = glm::vec3(0.03f, 0.03f, 0.08f);
        sc.horizon = glm::vec3(0.08f, 0.08f, 0.15f);
        sc.ambient = glm::vec3(0.18f, 0.20f, 0.25f);
        sc.sunColor = glm::vec3(0.15f, 0.15f, 0.3f);
    } else if (hour < 7.0f) {
        float t = (hour - 5.0f) / 2.0f;
        sc.zenith = lerp3(glm::vec3(0.02f, 0.02f, 0.08f), glm::vec3(0.35f, 0.25f, 0.55f), t);
        sc.horizon = lerp3(glm::vec3(0.05f, 0.05f, 0.15f), glm::vec3(0.85f, 0.5f, 0.2f), t);
        sc.sunColor = lerp3(glm::vec3(0.1f, 0.1f, 0.2f), glm::vec3(1.0f, 0.7f, 0.3f), t);
        sc.ambient = lerp3(glm::vec3(0.04f, 0.04f, 0.1f), glm::vec3(0.3f, 0.2f, 0.15f), t);
    } else if (hour < 10.0f) {
        float t = (hour - 7.0f) / 3.0f;
        sc.zenith = lerp3(glm::vec3(0.35f, 0.25f, 0.55f), glm::vec3(0.25f, 0.45f, 0.75f), t);
        sc.horizon = lerp3(glm::vec3(0.85f, 0.5f, 0.2f), glm::vec3(0.55f, 0.65f, 0.8f), t);
        sc.sunColor = lerp3(glm::vec3(1.0f, 0.7f, 0.3f), glm::vec3(1.0f, 0.95f, 0.8f), t);
        sc.ambient = lerp3(glm::vec3(0.3f, 0.2f, 0.15f), glm::vec3(0.4f, 0.4f, 0.4f), t);
    } else if (hour < 16.0f) {
        sc.zenith = glm::vec3(0.22f, 0.42f, 0.72f);
        sc.horizon = glm::vec3(0.52f, 0.62f, 0.78f);
        sc.sunColor = glm::vec3(1.0f, 0.96f, 0.88f);
        sc.ambient = glm::vec3(0.42f, 0.42f, 0.42f);
    } else if (hour < 19.0f) {
        float t = (hour - 16.0f) / 3.0f;
        sc.zenith = lerp3(glm::vec3(0.22f, 0.42f, 0.72f), glm::vec3(0.12f, 0.08f, 0.2f), t);
        sc.horizon = lerp3(glm::vec3(0.52f, 0.62f, 0.78f), glm::vec3(0.9f, 0.4f, 0.1f), t);
        sc.sunColor = lerp3(glm::vec3(1.0f, 0.96f, 0.88f), glm::vec3(1.0f, 0.5f, 0.1f), t);
        sc.ambient = lerp3(glm::vec3(0.42f, 0.42f, 0.42f), glm::vec3(0.2f, 0.12f, 0.08f), t);
    } else if (hour < 21.0f) {
        float t = (hour - 19.0f) / 2.0f;
        sc.zenith = lerp3(glm::vec3(0.12f, 0.08f, 0.2f), glm::vec3(0.02f, 0.02f, 0.08f), t);
        sc.horizon = lerp3(glm::vec3(0.9f, 0.4f, 0.1f), glm::vec3(0.06f, 0.06f, 0.15f), t);
        sc.sunColor = lerp3(glm::vec3(1.0f, 0.5f, 0.1f), glm::vec3(0.1f, 0.1f, 0.25f), t);
        sc.ambient = lerp3(glm::vec3(0.2f, 0.12f, 0.08f), glm::vec3(0.05f, 0.05f, 0.1f), t);
    } else {
        sc.zenith = glm::vec3(0.03f, 0.03f, 0.08f);
        sc.horizon = glm::vec3(0.08f, 0.08f, 0.15f);
        sc.sunColor = glm::vec3(0.15f, 0.15f, 0.3f);
        sc.ambient = glm::vec3(0.18f, 0.20f, 0.25f);
    }
    return sc;
}

glm::vec3 getSunDirection(float tod) {
    float angle = tod * 2.0f * M_PI;
    float elevation = sin(angle);
    float horizontal = cos(angle);
    glm::vec3 dir = glm::normalize(glm::vec3(horizontal, elevation, 0.2f));
    return dir;
}

// ─── Input Callbacks ───────────────────────────────────────────────────────
void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods) {
    if (button == GLFW_MOUSE_BUTTON_LEFT) {
        isMousePressed = (action == GLFW_PRESS);
        if (isMousePressed) glfwGetCursorPos(window, &lastMouseX, &lastMouseY);
    }
}

void cursorPosCallback(GLFWwindow* window, double xpos, double ypos) {
    if (isMousePressed) {
        double dx = xpos - lastMouseX;
        double dy = ypos - lastMouseY;
        camAngle += dx * 0.005f;
        camPitch = glm::clamp(camPitch + (float)dy * 0.003f, 0.05f, 0.6f);
        lastMouseX = xpos;
        lastMouseY = ypos;
    }
}

void scrollCallback(GLFWwindow* window, double xoffset, double yoffset) {
    camDist = glm::clamp(camDist - (float)yoffset * 0.5f, 5.0f, 50.0f);
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (action == GLFW_PRESS) {
        switch (key) {
            case GLFW_KEY_1:
                currentWeather = CLEAR;
                snowCoverage = 0.0f;
                weatherTarget = {0.05f, 0.1f, 0.0f, 0.0f};
                break;
            case GLFW_KEY_2:
                currentWeather = CLOUDY;
                weatherTarget = {0.8f, 0.35f, 0.0f, 0.0f};
                break;
            case GLFW_KEY_3:
                currentWeather = RAIN;
                weatherTarget = {0.95f, 0.5f, 1.0f, 0.0f};
                break;
            case GLFW_KEY_4:
                currentWeather = STORM;
                weatherTarget = {1.0f, 0.6f, 1.0f, 0.0f};
                break;
            case GLFW_KEY_5:
                currentWeather = FOG;
                weatherTarget = {0.4f, 0.9f, 0.0f, 0.0f};
                break;
            case GLFW_KEY_6:
                currentWeather = SNOW;
                snowCoverage = 100.0f;
                weatherTarget = {0.75f, 0.4f, 0.0f, 1.0f};
                break;
            case GLFW_KEY_8:  // NEW: Shooting Stars
                showShootingStars = !showShootingStars;
                std::cout << "Shooting Stars: " << (showShootingStars ? "ON" : "OFF") << std::endl;
                break;
            case GLFW_KEY_9:  // NEW: Hot Air Balloons
                showHotAirBalloons = !showHotAirBalloons;
                std::cout << "Hot Air Balloons: " << (showHotAirBalloons ? "ON" : "OFF") << std::endl;
                break;
            case GLFW_KEY_P:
                showPlane = !showPlane;
                break;
            case GLFW_KEY_A:
                if (action == GLFW_PRESS) {
                    showAurora = !showAurora;
                    std::cout << "Aurora toggled: " << (showAurora ? "ON" : "OFF") << std::endl;
                }
                break;
            case GLFW_KEY_B:
                showBirds = !showBirds;
                break;
            case GLFW_KEY_G:
                if (action == GLFW_PRESS) {
                    showGrass = !showGrass;
                    std::cout << "Grass toggled: " << (showGrass ? "ON" : "OFF") << std::endl;
                }
                break;
            case GLFW_KEY_UP:
                timeSpeed = glm::min(timeSpeed + 5.0f, 200.0f);
                break;
            case GLFW_KEY_DOWN:
                timeSpeed = glm::max(timeSpeed - 5.0f, 1.0f);
                break;
            case GLFW_KEY_ESCAPE:
                glfwSetWindowShouldClose(window, GLFW_TRUE);
                break;
        }
    }
}

struct BasicMesh {
    GLuint VAO, VBO;
    int count;
};

BasicMesh createBirdMesh() {
    float verts[] = {
        0.0f, 0.0f, 0.0f,  -0.5f, 0.2f, -0.3f,
        0.0f, 0.0f, 0.0f,   0.5f, 0.2f, -0.3f
    };
    BasicMesh m;
    glGenVertexArrays(1, &m.VAO); glGenBuffers(1, &m.VBO);
    glBindVertexArray(m.VAO);
    glBindBuffer(GL_ARRAY_BUFFER, m.VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(0);
    m.count = 6;
    return m;
}

// ─── IMPROVED: Realistic Plane Mesh ───────────────────────────────────────
BasicMesh createPlaneMesh() {
    std::vector<float> verts;

    // Helper: add triangle
    auto tri = [&](float x0,float y0,float z0,
                   float x1,float y1,float z1,
                   float x2,float y2,float z2) {
        verts.insert(verts.end(), {x0,y0,z0, x1,y1,z1, x2,y2,z2});
    };
    // Helper: add quad as 2 triangles
    auto quad = [&](float x0,float y0,float z0,
                    float x1,float y1,float z1,
                    float x2,float y2,float z2,
                    float x3,float y3,float z3) {
        verts.insert(verts.end(), {x0,y0,z0, x1,y1,z1, x2,y2,z2});
        verts.insert(verts.end(), {x0,y0,z0, x2,y2,z2, x3,y3,z3});
    };

    const int FSIDES = 8; // octagonal fuselage

    // ── Fuselage cross-sections (z, radius, yOffset) ──
    struct Ring { float z, r, yo; };
    Ring rings[] = {
        { 3.2f, 0.05f, 0.0f },  // nose tip
        { 2.5f, 0.28f, 0.05f }, // nose
        { 1.8f, 0.40f, 0.08f }, // cockpit front
        { 1.0f, 0.42f, 0.06f }, // cockpit rear
        { 0.0f, 0.40f, 0.0f  }, // mid / wing root
        {-1.0f, 0.37f, 0.0f  }, // aft
        {-2.0f, 0.28f, 0.0f  }, // tail taper
        {-3.0f, 0.15f, 0.0f  }, // tail
        {-3.8f, 0.04f, 0.0f  }  // tail tip
    };
    const int NR = 9;

    // Build ring vertex positions
    auto ringPt = [&](Ring& ring, int s) -> glm::vec3 {
        float a = (s / (float)FSIDES) * 2.0f * M_PI;
        return glm::vec3(cos(a) * ring.r, sin(a) * ring.r + ring.yo, ring.z);
    };

    // Connect rings with quads
    for (int r = 0; r < NR - 1; r++) {
        for (int s = 0; s < FSIDES; s++) {
            int s1 = (s + 1) % FSIDES;
            glm::vec3 a = ringPt(rings[r],   s);
            glm::vec3 b = ringPt(rings[r],   s1);
            glm::vec3 c = ringPt(rings[r+1], s1);
            glm::vec3 d = ringPt(rings[r+1], s);
            quad(a.x,a.y,a.z, b.x,b.y,b.z, c.x,c.y,c.z, d.x,d.y,d.z);
        }
    }

    // Nose cap (fan from tip to first ring)
    {
        glm::vec3 tip(0.0f, rings[0].yo, rings[0].z);
        for (int s = 0; s < FSIDES; s++) {
            int s1 = (s + 1) % FSIDES;
            glm::vec3 a = ringPt(rings[1], s);
            glm::vec3 b = ringPt(rings[1], s1);
            tri(tip.x,tip.y,tip.z, a.x,a.y,a.z, b.x,b.y,b.z);
        }
    }

    // Tail cap
    {
        glm::vec3 tip(0.0f, rings[NR-1].yo, rings[NR-1].z);
        for (int s = 0; s < FSIDES; s++) {
            int s1 = (s + 1) % FSIDES;
            glm::vec3 a = ringPt(rings[NR-2], s);
            glm::vec3 b = ringPt(rings[NR-2], s1);
            tri(tip.x,tip.y,tip.z, b.x,b.y,b.z, a.x,a.y,a.z);
        }
    }

    // ── Cockpit canopy bump (top of fuselage rings 2-3) ──
    // A raised dome over the cockpit section
    for (int s = 0; s < 3; s++) { // top 3 segments of ring
        float a0 = (s / (float)FSIDES) * 2.0f * M_PI;
        float a1 = ((s+1) / (float)FSIDES) * 2.0f * M_PI;
        // Canopy spans from z=1.8 to z=0.8
        quad(
            cos(a0)*0.38f, sin(a0)*0.38f+0.25f, 1.8f,
            cos(a1)*0.38f, sin(a1)*0.38f+0.25f, 1.8f,
            cos(a1)*0.38f, sin(a1)*0.38f+0.25f, 0.8f,
            cos(a0)*0.38f, sin(a0)*0.38f+0.25f, 0.8f
        );
    }
    // Mirror top side
    for (int s = FSIDES-3; s < FSIDES; s++) {
        float a0 = (s / (float)FSIDES) * 2.0f * M_PI;
        float a1 = ((s+1) / (float)FSIDES) * 2.0f * M_PI;
        quad(
            cos(a0)*0.38f, sin(a0)*0.38f+0.25f, 1.8f,
            cos(a1)*0.38f, sin(a1)*0.38f+0.25f, 1.8f,
            cos(a1)*0.38f, sin(a1)*0.38f+0.25f, 0.8f,
            cos(a0)*0.38f, sin(a0)*0.38f+0.25f, 0.8f
        );
    }

    // ── SWEPT-BACK WINGS ──
    // Right wing (4 triangles for top + bottom surface)
    //   Root leading:  (0.4, 0.0,  1.2)
    //   Root trailing: (0.4, 0.0, -0.5)
    //   Tip leading:   (6.5, 0.0, -0.8)
    //   Tip trailing:  (6.5, 0.0, -2.0)
    float wt = 0.08f; // wing thickness
    // Right wing top
    quad( 0.4f, wt, 1.2f,   6.5f, wt*0.3f,-0.8f,
          6.5f, wt*0.3f,-2.0f,  0.4f, wt,-0.5f);
    // Right wing bottom
    quad( 0.4f,-wt, 1.2f,   0.4f,-wt,-0.5f,
          6.5f,-wt*0.3f,-2.0f,  6.5f,-wt*0.3f,-0.8f);
    // Right wing leading edge
    quad( 0.4f, wt, 1.2f,   0.4f,-wt, 1.2f,
          6.5f,-wt*0.3f,-0.8f,  6.5f, wt*0.3f,-0.8f);
    // Right wing trailing edge
    quad( 0.4f, wt,-0.5f,   6.5f, wt*0.3f,-2.0f,
          6.5f,-wt*0.3f,-2.0f,  0.4f,-wt,-0.5f);
    // Right wingtip cap
    quad( 6.5f, wt*0.3f,-0.8f, 6.5f,-wt*0.3f,-0.8f,
          6.5f,-wt*0.3f,-2.0f, 6.5f, wt*0.3f,-2.0f);

    // Left wing (mirror of right)
    quad(-0.4f, wt, 1.2f,  -0.4f, wt,-0.5f,
         -6.5f, wt*0.3f,-2.0f, -6.5f, wt*0.3f,-0.8f);
    quad(-0.4f,-wt, 1.2f,  -6.5f,-wt*0.3f,-0.8f,
         -6.5f,-wt*0.3f,-2.0f,  -0.4f,-wt,-0.5f);
    quad(-0.4f, wt, 1.2f,  -6.5f, wt*0.3f,-0.8f,
         -6.5f,-wt*0.3f,-0.8f,  -0.4f,-wt, 1.2f);
    quad(-0.4f, wt,-0.5f,  -0.4f,-wt,-0.5f,
         -6.5f,-wt*0.3f,-2.0f, -6.5f, wt*0.3f,-2.0f);
    quad(-6.5f, wt*0.3f,-0.8f, -6.5f, wt*0.3f,-2.0f,
         -6.5f,-wt*0.3f,-2.0f, -6.5f,-wt*0.3f,-0.8f);

    // ── ENGINE NACELLES (under each wing at ~40% span) ──
    // Simple 6-sided cylinders + cones
    auto addNacelle = [&](float cx, float cz) {
        const int NS = 6;
        float nr = 0.18f, nl = 1.4f; // radius, length
        // Cylinder body
        for (int s = 0; s < NS; s++) {
            float a0 = (s/(float)NS)*2.0f*M_PI;
            float a1 = ((s+1)/(float)NS)*2.0f*M_PI;
            float x0=cos(a0)*nr, y0=sin(a0)*nr;
            float x1=cos(a1)*nr, y1=sin(a1)*nr;
            quad(cx+x0, -0.25f+y0, cz+0.6f,
                 cx+x1, -0.25f+y1, cz+0.6f,
                 cx+x1, -0.25f+y1, cz+0.6f-nl,
                 cx+x0, -0.25f+y0, cz+0.6f-nl);
        }
        // Intake cap (front cone)
        glm::vec3 intakeTip(cx, -0.25f, cz+0.9f);
        for (int s = 0; s < NS; s++) {
            float a0 = (s/(float)NS)*2.0f*M_PI;
            float a1 = ((s+1)/(float)NS)*2.0f*M_PI;
            tri(intakeTip.x, intakeTip.y, intakeTip.z,
                cx+cos(a0)*nr, -0.25f+sin(a0)*nr, cz+0.6f,
                cx+cos(a1)*nr, -0.25f+sin(a1)*nr, cz+0.6f);
        }
        // Exhaust cap
        glm::vec3 exhaustTip(cx, -0.25f, cz+0.6f-nl-0.2f);
        for (int s = 0; s < NS; s++) {
            float a0 = (s/(float)NS)*2.0f*M_PI;
            float a1 = ((s+1)/(float)NS)*2.0f*M_PI;
            tri(exhaustTip.x, exhaustTip.y, exhaustTip.z,
                cx+cos(a1)*nr, -0.25f+sin(a1)*nr, cz+0.6f-nl,
                cx+cos(a0)*nr, -0.25f+sin(a0)*nr, cz+0.6f-nl);
        }
    };

    addNacelle( 2.8f,  0.2f); // right engine
    addNacelle(-2.8f,  0.2f); // left engine

    // ── VERTICAL TAIL FIN ──
    quad( 0.08f, 0.40f,-2.2f,   0.08f, 2.0f,-3.2f,
         -0.08f, 2.0f,-3.2f,   -0.08f, 0.40f,-2.2f);
    // Top of fin
    tri( 0.08f, 2.0f,-3.2f,  0.0f, 2.2f,-3.0f, -0.08f, 2.0f,-3.2f);
    // Front slope of fin
    quad( 0.08f, 0.40f,-2.2f, -0.08f, 0.40f,-2.2f,
         -0.08f, 2.0f,-3.2f,   0.08f, 2.0f,-3.2f);

    // ── HORIZONTAL STABILIZERS ──
    float hs = 0.06f; // stabilizer thickness
    // Right stabilizer
    quad( 0.4f, hs,-2.5f,   2.8f, hs,-3.2f,   2.8f,-hs,-3.2f,   0.4f,-hs,-2.5f);
    tri( 2.8f, hs,-3.2f,  2.8f,-hs,-3.2f,  3.0f, 0.0f,-3.4f);
    // Left stabilizer
    quad(-0.4f, hs,-2.5f,  -0.4f,-hs,-2.5f,  -2.8f,-hs,-3.2f,  -2.8f, hs,-3.2f);
    tri(-2.8f, hs,-3.2f, -3.0f, 0.0f,-3.4f, -2.8f,-hs,-3.2f);

    BasicMesh mesh;
    mesh.count = (int)(verts.size() / 3);
    glGenVertexArrays(1, &mesh.VAO);
    glBindVertexArray(mesh.VAO);
    GLuint vbo;
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(float), verts.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    return mesh;
}

struct ShootingStar {
    glm::vec3 headPos;
    glm::vec3 direction; // normalized
    float speed;
    float life;       // current lifetime 0..1 (1=fresh, 0=dead)
    float tailLen;
    bool active;
};

const int NUM_SHOOTING_STARS = 15;
ShootingStar shootingStars[NUM_SHOOTING_STARS];
GLuint ssVAO, ssVBO;
GLuint progShootingStar;

void initShootingStars() {
    for (int i = 0; i < NUM_SHOOTING_STARS; i++) {
        shootingStars[i].active = false;
        shootingStars[i].life = 0.0f;
    }
    glGenVertexArrays(1, &ssVAO);
    glGenBuffers(1, &ssVBO);
    glBindVertexArray(ssVAO);
    glBindBuffer(GL_ARRAY_BUFFER, ssVBO);
    // 2 points per star * 3 floats
    glBufferData(GL_ARRAY_BUFFER, NUM_SHOOTING_STARS * 2 * 3 * sizeof(float), nullptr, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);
}

void spawnShootingStar(ShootingStar& ss) {
    // Random start in sky (high altitude, spread across scene)
    ss.headPos.x = ((float)rand()/RAND_MAX - 0.5f) * 300.0f;
    ss.headPos.y = 80.0f + ((float)rand()/RAND_MAX) * 60.0f;
    ss.headPos.z = -50.0f + ((float)rand()/RAND_MAX - 0.5f) * 200.0f;
    // Direction: mostly downward with horizontal component
    float dx = ((float)rand()/RAND_MAX - 0.5f) * 1.0f;
    float dy = -0.6f - (float)rand()/RAND_MAX * 0.4f;
    float dz = ((float)rand()/RAND_MAX - 0.5f) * 0.5f;
    ss.direction = glm::normalize(glm::vec3(dx, dy, dz));
    ss.speed = 120.0f + (float)rand()/RAND_MAX * 80.0f;
    ss.life = 1.0f;
    ss.tailLen = 8.0f + (float)rand()/RAND_MAX * 12.0f;
    ss.active = true;
}

void updateAndRenderShootingStars(float dt, const glm::mat4& VP, GLuint prog) {
    // Spawn new stars occasionally
    static float spawnTimer = 0.0f;
    spawnTimer -= dt;
    if (spawnTimer <= 0.0f) {
        // Find an inactive slot
        for (int i = 0; i < NUM_SHOOTING_STARS; i++) {
            if (!shootingStars[i].active) {
                spawnShootingStar(shootingStars[i]);
                break;
            }
        }
        spawnTimer = 0.3f + (float)rand()/RAND_MAX * 0.8f;
    }

    // Build line vertex pairs
    std::vector<float> lineVerts;
    lineVerts.reserve(NUM_SHOOTING_STARS * 6);

    for (int i = 0; i < NUM_SHOOTING_STARS; i++) {
        if (!shootingStars[i].active) continue;
        ShootingStar& ss = shootingStars[i];

        // Move head
        ss.headPos += ss.direction * ss.speed * dt;
        ss.life -= dt * 0.8f;
        if (ss.life <= 0.0f) { ss.active = false; continue; }

        // Tail position
        glm::vec3 tail = ss.headPos - ss.direction * ss.tailLen * ss.life;

        // Head vertex
        lineVerts.push_back(ss.headPos.x);
        lineVerts.push_back(ss.headPos.y);
        lineVerts.push_back(ss.headPos.z);
        // Tail vertex
        lineVerts.push_back(tail.x);
        lineVerts.push_back(tail.y);
        lineVerts.push_back(tail.z);
    }

    if (lineVerts.empty()) return;

    // Upload + draw
    glBindBuffer(GL_ARRAY_BUFFER, ssVBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, lineVerts.size() * sizeof(float), lineVerts.data());

    glUseProgram(prog);
    glUniformMatrix4fv(glGetUniformLocation(prog, "uVP"), 1, GL_FALSE, glm::value_ptr(VP));
    glUniform3f(glGetUniformLocation(prog, "uColor"), 1.0f, 1.0f, 0.9f);
    glUniform1f(glGetUniformLocation(prog, "uAlpha"), 0.9f);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glLineWidth(2.0f);

    glBindVertexArray(ssVAO);
    glDrawArrays(GL_LINES, 0, (GLsizei)(lineVerts.size() / 3));

    glLineWidth(1.0f);
    glDisable(GL_BLEND);
}

struct BalloonInstance {
    glm::vec3 basePos;  // base spawn position
    float phase;        // for bobbing animation
    float bobSpeed;
    float driftAngle;
    float driftSpeed;
    glm::vec3 color1;
    glm::vec3 color2;
};

const int NUM_BALLOONS = 5;
BalloonInstance balloonInstances[NUM_BALLOONS];
GLuint balloonMeshVAO, balloonMeshVBO;
int balloonMeshVertCount;
GLuint progBalloon;
//ballon
void initBalloonMesh() {
    std::vector<float> verts;

    auto tri = [&](float x0,float y0,float z0,
                   float x1,float y1,float z1,
                   float x2,float y2,float z2) {
        verts.insert(verts.end(), {x0,y0,z0, x1,y1,z1, x2,y2,z2});
    };
    auto quad = [&](float x0,float y0,float z0,
                    float x1,float y1,float z1,
                    float x2,float y2,float z2,
                    float x3,float y3,float z3) {
        verts.insert(verts.end(), {x0,y0,z0, x1,y1,z1, x2,y2,z2});
        verts.insert(verts.end(), {x0,y0,z0, x2,y2,z2, x3,y3,z3});
    };

    const int BSLICES = 10;  // horizontal slices
    const int BSEGS   = 12;  // segments per ring


    struct BRing { float h, r; };
    BRing bRings[] = {
        {0.00f, 0.05f}, // very bottom (pinch)
        {0.10f, 0.50f},
        {0.25f, 0.85f},
        {0.40f, 1.00f}, // widest
        {0.55f, 0.95f},
        {0.68f, 0.80f},
        {0.78f, 0.60f},
        {0.88f, 0.38f},
        {0.94f, 0.18f},
        {1.00f, 0.04f}  // top
    };
    const int NBR = 10;
    float balloonR = 3.5f;
    float balloonH = 8.0f; // total height
    float balloonYOff = 2.0f; // base Y offset

    auto bPt = [&](int ring, int seg) -> glm::vec3 {
        float a = (seg / (float)BSEGS) * 2.0f * M_PI;
        float r = bRings[ring].r * balloonR;
        float y = bRings[ring].h * balloonH + balloonYOff;
        return glm::vec3(cos(a) * r, y, sin(a) * r);
    };

    for (int r = 0; r < NBR - 1; r++) {
        for (int s = 0; s < BSEGS; s++) {
            int s1 = (s + 1) % BSEGS;
            glm::vec3 a = bPt(r, s);
            glm::vec3 b = bPt(r, s1);
            glm::vec3 c = bPt(r+1, s1);
            glm::vec3 d = bPt(r+1, s);
            quad(a.x,a.y,a.z, b.x,b.y,b.z, c.x,c.y,c.z, d.x,d.y,d.z);
        }
    }
    // Bottom cap
    glm::vec3 bBot(0.0f, balloonYOff, 0.0f);
    for (int s = 0; s < BSEGS; s++) {
        int s1 = (s + 1) % BSEGS;
        glm::vec3 a = bPt(0, s);
        glm::vec3 b = bPt(0, s1);
        tri(bBot.x,bBot.y,bBot.z, b.x,b.y,b.z, a.x,a.y,a.z);
    }
    // Top cap
    glm::vec3 bTop(0.0f, balloonH + balloonYOff, 0.0f);
    for (int s = 0; s < BSEGS; s++) {
        int s1 = (s + 1) % BSEGS;
        glm::vec3 a = bPt(NBR-1, s);
        glm::vec3 b = bPt(NBR-1, s1);
        tri(bTop.x,bTop.y,bTop.z, a.x,a.y,a.z, b.x,b.y,b.z);
    }

    float bx = 0.7f, by = 0.9f, bz = 0.7f;  // half-extents
    float bY0 = -1.0f, bY1 = bY0 + 1.2f;    // bottom and top of basket

    // Front face
    quad(-bx, bY0,-bz,  bx, bY0,-bz,  bx, bY1,-bz, -bx, bY1,-bz);
    // Back face
    quad( bx, bY0, bz, -bx, bY0, bz, -bx, bY1, bz,  bx, bY1, bz);
    // Left face
    quad(-bx, bY0, bz, -bx, bY0,-bz, -bx, bY1,-bz, -bx, bY1, bz);
    // Right face
    quad( bx, bY0,-bz,  bx, bY0, bz,  bx, bY1, bz,  bx, bY1,-bz);
    // Bottom face
    quad(-bx, bY0,-bz, -bx, bY0, bz,  bx, bY0, bz,  bx, bY0,-bz);


    float ropeW = 0.04f;
    float balloonBaseY = balloonYOff + bRings[0].h * balloonH;
    float balloonBaseR = bRings[1].r * balloonR * 0.5f;
    // 4 ropes at basket corners
    float cx[4] = {-bx+0.1f,  bx-0.1f,  bx-0.1f, -bx+0.1f};
    float cz2[4] = {-bz+0.1f, -bz+0.1f,  bz-0.1f,  bz-0.1f};
    float bAttach[4][2] = {
        {-balloonBaseR*0.6f, -balloonBaseR*0.6f},
        { balloonBaseR*0.6f, -balloonBaseR*0.6f},
        { balloonBaseR*0.6f,  balloonBaseR*0.6f},
        {-balloonBaseR*0.6f,  balloonBaseR*0.6f}
    };
    for (int r = 0; r < 4; r++) {
        float tx = bAttach[r][0], tz = bAttach[r][1];
        quad(cx[r]-ropeW, bY1, cz2[r],
             cx[r]+ropeW, bY1, cz2[r],
             tx+ropeW, balloonBaseY, tz,
             tx-ropeW, balloonBaseY, tz);
    }

    // ── Burner glow (small flat disc at bottom of balloon opening) ──
    float gR = 0.3f, gY = balloonYOff + 0.3f;
    for (int s = 0; s < 8; s++) {
        float a0 = (s/8.0f)*2.0f*M_PI;
        float a1 = ((s+1)/8.0f)*2.0f*M_PI;
        tri(0.0f, gY, 0.0f,
            cos(a0)*gR, gY, sin(a0)*gR,
            cos(a1)*gR, gY, sin(a1)*gR);
    }

    balloonMeshVertCount = (int)(verts.size() / 3);
    glGenVertexArrays(1, &balloonMeshVAO);
    glBindVertexArray(balloonMeshVAO);
    glGenBuffers(1, &balloonMeshVBO);
    glBindBuffer(GL_ARRAY_BUFFER, balloonMeshVBO);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(float), verts.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);
}

void initBalloonInstances() {
    // Balloon color pairs
    glm::vec3 colors1[] = {
        {1.0f,0.2f,0.1f}, {0.1f,0.4f,0.9f}, {0.9f,0.7f,0.0f},
        {0.1f,0.7f,0.3f}, {0.8f,0.1f,0.8f}
    };
    glm::vec3 colors2[] = {
        {1.0f,0.9f,0.1f}, {1.0f,1.0f,1.0f}, {0.9f,0.2f,0.1f},
        {0.9f,0.9f,0.0f}, {0.2f,0.9f,0.9f}
    };
    for (int i = 0; i < NUM_BALLOONS; i++) {
        balloonInstances[i].basePos = glm::vec3(
            -60.0f + i * 28.0f,
            120.0f + (float)(i % 3) * 8.0f,
            -40.0f + (float)(i % 2) * 20.0f
        );
        balloonInstances[i].phase = (float)i * 1.5f;
        balloonInstances[i].bobSpeed = 0.4f + i * 0.1f;
        balloonInstances[i].driftAngle = (float)i * 1.2f;
        balloonInstances[i].driftSpeed = 0.05f + i * 0.01f;
        balloonInstances[i].color1 = colors1[i];
        balloonInstances[i].color2 = colors2[i];
    }
}

void renderHotAirBalloons(float currentTime, const glm::mat4& VP, GLuint prog) {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(prog);
    glBindVertexArray(balloonMeshVAO);

    for (int i = 0; i < NUM_BALLOONS; i++) {
        BalloonInstance& b = balloonInstances[i];

        // Gentle bob + drift animation
        float bob = sin(currentTime * b.bobSpeed + b.phase) * 1.5f;
        float drift = cos(currentTime * b.driftSpeed + b.driftAngle) * 5.0f;

        glm::vec3 pos = b.basePos + glm::vec3(drift, bob, 0.0f);

        glm::mat4 model = glm::mat4(1.0f);
        model = glm::translate(model, pos);
        // Gentle sway
        float swayAngle = sin(currentTime * 0.3f + b.phase) * 0.04f;
        model = glm::rotate(model, swayAngle, glm::vec3(0, 0, 1));
        model = glm::scale(model, glm::vec3(1.2f));

        glUniformMatrix4fv(glGetUniformLocation(prog, "uMVP"), 1, GL_FALSE,
                           glm::value_ptr(VP * model));
        glUniform3fv(glGetUniformLocation(prog, "uColor"),  1, glm::value_ptr(b.color1));
        glUniform3fv(glGetUniformLocation(prog, "uColor2"), 1, glm::value_ptr(b.color2));

        glDrawArrays(GL_TRIANGLES, 0, balloonMeshVertCount);
    }
    glDisable(GL_BLEND);
}

// ─── Heavy Rain ────────────────────────────────────────────────────────────
void updateHeavyRain(int particleCount, std::vector<glm::vec3>& pos, float dt) {
    for(int i=0; i<particleCount; i++) {
        pos[i].y -= dt * 25.0f;
        pos[i].x += dt * 5.0f;
        if(pos[i].y < -2.0f) pos[i].y = 30.0f;
    }
}

FireflySystem fireflies;

void renderFireflies(glm::mat4 VP, float tod, float currentTime) {
    SkyColors sc = getSkyColors(tod);
    float hour = tod * 24.0f;
    if (hour < 6.0f || hour > 19.0f) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_ONE, GL_ONE);
        glEnable(GL_PROGRAM_POINT_SIZE);
        glUseProgram(progFirefly);
        glUniformMatrix4fv(glGetUniformLocation(progFirefly, "uVP"), 1, GL_FALSE, glm::value_ptr(VP));
        glUniform1f(glGetUniformLocation(progFirefly, "uTime"), currentTime);
        glUniform1f(glGetUniformLocation(progFirefly, "uSize"), 5.0f);
        glUniform3fv(glGetUniformLocation(progFirefly, "uAmbient"), 1, glm::value_ptr(sc.ambient));
        glBindVertexArray(fireflies.VAO);
        glDrawArrays(GL_POINTS, 0, FireflySystem::COUNT);
        glDisable(GL_BLEND);
    }
}

void drawPlane(GLuint shader, const Plane& plane, glm::mat4 VP, glm::vec3 pos, float yaw, float tOfDay) {
    glUseProgram(shader);
    float currentTime = (float)glfwGetTime();
    bool isNight = (tOfDay < 0.25f || tOfDay > 0.8f);
    bool isBlinking = sin(currentTime * 15.0f) > 0.0f;
    GLint colorLoc = glGetUniformLocation(shader, "uColor");
    if (colorLoc != -1) glUniform3f(colorLoc, 0.8f, 0.8f, 0.85f);
    glUniform1i(glGetUniformLocation(shader, "uUseMixedColor"), 1);
    glUniform1i(glGetUniformLocation(shader, "uIsNight"), isNight ? 1 : 0);
    glUniform1f(glGetUniformLocation(shader, "uTime"), currentTime);
    glm::mat4 pModel = glm::mat4(1.0f);
    pModel = glm::translate(pModel, pos);
    pModel = glm::rotate(pModel, yaw, glm::vec3(0, 1, 0));
    pModel = glm::rotate(pModel, 0.05f * (float)sin(currentTime * 2.0f), glm::vec3(1, 0, 0));
    pModel = glm::scale(pModel, glm::vec3(5.0f, 5.0f, 5.0f));
    glUniformMatrix4fv(glGetUniformLocation(shader, "uMVP"), 1, GL_FALSE, glm::value_ptr(VP * pModel));
    glBindVertexArray(plane.VAO);
    glDrawArrays(GL_TRIANGLES, 0, plane.count);
    if (isNight && isBlinking) {
        glUniform1i(glGetUniformLocation(shader, "uIsNight"), 0);
        glm::mat4 leftLight = pModel;
        leftLight = glm::translate(leftLight, glm::vec3(0.0f, 0.2f, 2.5f));
        leftLight = glm::scale(leftLight, glm::vec3(0.15f));
        glUniform3f(colorLoc, 1.0f, 0.0f, 0.0f);
        glUniformMatrix4fv(glGetUniformLocation(shader, "uMVP"), 1, GL_FALSE, glm::value_ptr(VP * leftLight));
        glDrawArrays(GL_TRIANGLES, 0, plane.count);
        glm::mat4 rightLight = pModel;
        rightLight = glm::translate(rightLight, glm::vec3(0.0f, 0.2f, -2.5f));
        rightLight = glm::scale(rightLight, glm::vec3(0.15f));
        glUniform3f(colorLoc, 0.0f, 1.0f, 0.0f);
        glUniformMatrix4fv(glGetUniformLocation(shader, "uMVP"), 1, GL_FALSE, glm::value_ptr(VP * rightLight));
        glDrawArrays(GL_TRIANGLES, 0, plane.count);
    }
    glBindVertexArray(0);
}

void renderScene(GLuint shader, BasicMesh birdMesh, BasicMesh planeMesh, const Plane& plane,
                 glm::mat4 VP, float tOfDay, float runningTime, bool shouldDrawPlane, bool showBirds) {
    glUseProgram(shader);
    GLint mixedLoc = glGetUniformLocation(shader, "uUseMixedColor");
    if (showBirds) {
        glUniform1i(mixedLoc, 0);
        glUniform3f(glGetUniformLocation(shader, "uColor"), 0.0f, 0.0f, 0.0f);
        for(int i = 0; i < 150; i++) {
            float speed = 5.0f + (fmod(i * 1.3f, 15.0f));
            float rangeX = 600.0f;
            float startX = 300.0f;
            float globalSpeedMultiplier = 2.0f;
            float birdX = startX - fmod((runningTime * globalSpeedMultiplier + i * 15.0f) * speed, rangeX);
            float birdY = 15.0f + fmod(i * 7.0f, 80.0f) + sin(runningTime + i) * 2.0f;
            float birdZ = -10.0f - fmod(i * 17.3f, 400.0f);
            glm::mat4 model = glm::mat4(1.0f);
            model = glm::translate(model, glm::vec3(birdX, birdY, birdZ));
            model = glm::rotate(model, 1.57f, glm::vec3(0, 1, 0));
            float flapFactor = sin(runningTime * 15.0f + (i * 0.7f));
            float wingScaleY = 0.6f + (flapFactor * 0.4f);
            model = glm::scale(model, glm::vec3(2.5f, wingScaleY, 1.0f));
            glUniformMatrix4fv(glGetUniformLocation(shader, "uMVP"), 1, GL_FALSE, glm::value_ptr(VP * model));
            glBindVertexArray(birdMesh.VAO);
            glDrawArrays(GL_LINES, 0, birdMesh.count);
        }
    }
    if (shouldDrawPlane) {
        drawPlane(shader, plane, VP, planePos, planeYaw, tOfDay);
    }
}

// ─── Main ──────────────────────────────────────────────────────────────────
int main() {
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_SAMPLES, 4);
    GLFWmonitor* monitor = glfwGetPrimaryMonitor();
const GLFWvidmode* mode = glfwGetVideoMode(monitor);

GLFWwindow* window = glfwCreateWindow(
    mode->width,
    mode->height,
    "Dynamic Nature Environment",
    monitor,   // fullscreen
    NULL
);

    if (!window) {
        std::cerr << "Failed to create window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetMouseButtonCallback(window, mouseButtonCallback);
    glfwSetCursorPosCallback(window, cursorPosCallback);
    glfwSetScrollCallback(window, scrollCallback);
    glfwSetKeyCallback(window, keyCallback);
    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed to initialize GLEW" << std::endl;
        return -1;
    }

    std::cout << "OpenGL " << glGetString(GL_VERSION) << std::endl;
    std::cout << "\n=== Dynamic Nature Environment ===" << std::endl;
    std::cout << "Controls:" << std::endl;
    std::cout << "  Drag mouse    - Rotate camera" << std::endl;
    std::cout << "  Scroll        - Zoom" << std::endl;
    std::cout << "  Up/Down Arrow - Time speed" << std::endl;
    std::cout << "  1             - Weather: Clear" << std::endl;
    std::cout << "  2             - Weather: Cloudy" << std::endl;
    std::cout << "  3             - Weather: Rain" << std::endl;
    std::cout << "  4             - Weather: Storm" << std::endl;
    std::cout << "  5             - Weather: Fog" << std::endl;
    std::cout << "  6             - Weather: Snow" << std::endl;
    std::cout << "  8             - Toggle Shooting Stars" << std::endl;
    std::cout << "  9             - Toggle Hot Air Balloons" << std::endl;
    std::cout << "  P             - Toggle Plane" << std::endl;
    std::cout << "  B             - Toggle Birds" << std::endl;
    std::cout << "  G             - Toggle Grass" << std::endl;
    std::cout << "  A             - Toggle Aurora Borealis" << std::endl;
    std::cout << "  ESC           - Quit" << std::endl;
    std::cout << "=================================\n" << std::endl;

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_MULTISAMPLE);
    glEnable(GL_PROGRAM_POINT_SIZE);
    glClearColor(0.1f, 0.1f, 0.15f, 1.0f);

    // Create programs
    GLuint progTerrain  = createProgram(terrainVS, terrainFS);
    GLuint progMountain = createProgram(mountainVS, terrainFS);
    GLuint progTree     = createProgram(treeVS, treeFS);
    GLuint progSky      = createProgram(skyVS, skyFS);
    GLuint progParticle = createProgram(particleVS, particleFS);
    GLuint progWater    = createProgram(waterVS, waterFS);
    GLuint progSimple   = createProgram(simpleVS, simpleFS);
    GLuint progWeather  = createProgram(weatherVS, weatherFS);
    GLuint progGrass    = createProgram(grassVS, grassFS);
    GLuint progSun      = createProgram(sunVS, sunFS);
    progFirefly         = createProgram(fireflyVS, fireflyFS);
    progShootingStar    = createProgram(shootingStarVS, shootingStarFS);
    progBalloon         = createProgram(balloonVS, balloonFS);

    initSun();
    fireflies.init();
    initGrass();
    initShootingStars();
    initBalloonMesh();
    initBalloonInstances();

    GLuint progAurora = createProgram(auroraVS, auroraFS);

    // Generate geometry
    Terrain terrain;
    generateTerrain(terrain);
    Forest forest;
    generateForest(forest);
    ParticleSystem particles;
    particles.init(0.0f, 0.0f);

    BasicMesh birdMesh  = createBirdMesh();
    Plane plane;
    BasicMesh planeMesh = createPlaneMesh();
    plane.VAO   = planeMesh.VAO;
    plane.count = planeMesh.count;

    // Sky quad
    float skyVerts[] = {
        -1, -1,  1, -1,  -1, 1,
         1, -1,  1,  1,  -1, 1
    };
    GLuint skyVAO, skyVBO;
    glGenVertexArrays(1, &skyVAO);
    glGenBuffers(1, &skyVBO);
    glBindVertexArray(skyVAO);
    glBindBuffer(GL_ARRAY_BUFFER, skyVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(skyVerts), skyVerts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Water surface
    float waterVerts[] = {
         6.0f,  -0.5f, -150.0f,
       200.0f,  -0.5f, -150.0f,
       200.0f,  -0.5f,  150.0f,
         6.0f,  -0.5f, -150.0f,
       200.0f,  -0.5f,  150.0f,
         6.0f,  -0.5f,  150.0f
    };
    GLuint waterVAO, waterVBO;
    glGenVertexArrays(1, &waterVAO);
    glGenBuffers(1, &waterVBO);
    glBindVertexArray(waterVAO);
    glBindBuffer(GL_ARRAY_BUFFER, waterVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(waterVerts), waterVerts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Aurora quad
    float auroraVertices[] = {
        -0.5f, -0.5f, 0.0f,  0.0f, 0.0f,
         0.5f, -0.5f, 0.0f,  1.0f, 0.0f,
         0.5f,  0.5f, 0.0f,  1.0f, 1.0f,
        -0.5f, -0.5f, 0.0f,  0.0f, 0.0f,
         0.5f,  0.5f, 0.0f,  1.0f, 1.0f,
        -0.5f,  0.5f, 0.0f,  0.0f, 1.0f
    };
    GLuint moonVAO, moonVBO;
    glGenVertexArrays(1, &moonVAO);
    glGenBuffers(1, &moonVBO);
    glBindVertexArray(moonVAO);
    glBindBuffer(GL_ARRAY_BUFFER, moonVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(auroraVertices), auroraVertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // Timing
    double lastTime = glfwGetTime();

    // Main loop
    while (!glfwWindowShouldClose(window)) {
        float sunAngle = timeOfDay * 2.0f * 3.14159f - 1.57f;
        float sunDist  = 400.0f;

        double currentTime = glfwGetTime();
        float dt = (float)(currentTime - lastTime);
        lastTime = currentTime;
        float currentFrame = (float)glfwGetTime();
        float deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;
        dt = glm::min(dt, 0.05f);

        // Update time of day
        timeOfDay = fmod(timeOfDay + dt * timeSpeed / 86400.0f, 1.0f);

        // Lerp weather
        weatherCurrent.clouds += (weatherTarget.clouds - weatherCurrent.clouds) * dt * 0.8f;
        weatherCurrent.fog    += (weatherTarget.fog    - weatherCurrent.fog)    * dt * 0.8f;
        weatherCurrent.rain   += (weatherTarget.rain   - weatherCurrent.rain)   * dt * 0.8f;
        weatherCurrent.snow   += (weatherTarget.snow   - weatherCurrent.snow)   * dt * 0.8f;

        // Camera
        float cx = camDist * cos(camAngle) * cos(camPitch);
        float cy = camDist * sin(camPitch) + 4.0f;
        float cz = camDist * sin(camAngle) * cos(camPitch);
        glm::vec3 camPos(cx, cy, cz);

        // Update Particles
        for (int i = 0; i < ParticleSystem::NPART; i++) {
            float fallSpeed = (currentWeather == RAIN || currentWeather == STORM) ? 80.0f : 37.5f;
            particles.positions[i].y -= fallSpeed * dt;
            particles.positions[i].x += weatherCurrent.rain * 12.0f * dt;
            if (particles.positions[i].y < terrainHeight(particles.positions[i].x, particles.positions[i].z)) {
                particles.positions[i].y = camPos.y + 25.0f;
                particles.positions[i].x = camPos.x + (float(rand()) / RAND_MAX - 0.5f) * 60.0f;
                particles.positions[i].z = camPos.z + (float(rand()) / RAND_MAX - 0.5f) * 60.0f;
                particles.lifetimes[i] = 1.0f;
            }
        }

        glm::mat4 proj = glm::perspective(glm::radians(45.0f), (float)WIDTH / (float)HEIGHT, 0.1f, 1000.0f);
        glm::mat4 view = glm::lookAt(camPos, glm::vec3(0, 2, 0), glm::vec3(0, 1, 0));
        glm::mat4 VP   = proj * view;

        glm::vec3 sunDir = getSunDirection(timeOfDay);
        SkyColors sc     = getSkyColors(timeOfDay);

        glm::vec3 sunPos;
        sunPos.x = cos(sunAngle) * sunDist;
        sunPos.y = sin(sunAngle) * sunDist;
        sunPos.z = -150.0f;

        float fogDensity = weatherCurrent.fog + manualFog * 0.5f;
        glm::vec3 fogColor = glm::mix(sc.horizon, sc.zenith, 0.3f);

        // Update particles
        particles.update(dt, weatherCurrent, manualWind, camPos, VP);
        particles.updateGPU();

        // ── Render ──────────────────────────────────────────────────────
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Sky
        glDepthMask(GL_FALSE);
        glUseProgram(progSky);
        glBindVertexArray(skyVAO);
        glUniform3fv(glGetUniformLocation(progSky, "uZenith"),   1, glm::value_ptr(sc.zenith));
        glUniform3fv(glGetUniformLocation(progSky, "uHorizon"),  1, glm::value_ptr(sc.horizon));
        glUniform3fv(glGetUniformLocation(progSky, "uSunDir"),   1, glm::value_ptr(sunDir));
        glUniform3fv(glGetUniformLocation(progSky, "uSunColor"), 1, glm::value_ptr(sc.sunColor));
        glUniform1f(glGetUniformLocation(progSky, "uTime"),      (float)currentTime);
        glUniform1f(glGetUniformLocation(progSky, "uClouds"),    weatherCurrent.clouds);
        glUniform1f(glGetUniformLocation(progSky, "uWeather"),   currentWeather == STORM ? 3.0f : 0.0f);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glDepthMask(GL_TRUE);

        // Terrain
        glUseProgram(progTerrain);
        glBindVertexArray(terrain.VAO);
        glUniform3fv(glGetUniformLocation(progTerrain, "uSunDir"),   1, glm::value_ptr(sunDir));
        glUniform3fv(glGetUniformLocation(progTerrain, "uSunColor"), 1, glm::value_ptr(sc.sunColor));
        glUniform3fv(glGetUniformLocation(progTerrain, "uFogColor"), 1, glm::value_ptr(fogColor));
        glUniform3fv(glGetUniformLocation(progTerrain, "uCamPos"),   1, glm::value_ptr(camPos));
        glUniform1f(glGetUniformLocation(progTerrain, "uTime"),      (float)currentTime);
        glUniform3fv(glGetUniformLocation(progTerrain, "uAmbient"),  1, glm::value_ptr(sc.ambient));
        glUniform1f(glGetUniformLocation(progTerrain, "uFogDensity"), fogDensity);
        glm::mat4 foregroundModel = glm::scale(glm::mat4(1.0f), glm::vec3(3.0f, 1.0f, 3.0f));
        glUniformMatrix4fv(glGetUniformLocation(progTerrain, "uModel"), 1, GL_FALSE, glm::value_ptr(foregroundModel));
        glUniformMatrix4fv(glGetUniformLocation(progTerrain, "uMVP"),   1, GL_FALSE, glm::value_ptr(VP * foregroundModel));
        glDrawElements(GL_TRIANGLES, terrain.indexCount, GL_UNSIGNED_INT, 0);

        glUniform3f(glGetUniformLocation(progTerrain, "uAmbient"), 0.05f, 0.05f, 0.1f);
        glUniform1f(glGetUniformLocation(progTerrain, "uFogDensity"), fogDensity * 0.5f);
        glm::mat4 modelLeft  = glm::translate(glm::mat4(1.0f), glm::vec3(-120.0f,-2.0f,0.0f));
        modelLeft  = glm::scale(modelLeft,  glm::vec3(5.0f, 4.0f, 5.0f));
        glUniformMatrix4fv(glGetUniformLocation(progTerrain, "uModel"), 1, GL_FALSE, glm::value_ptr(modelLeft));
        glUniformMatrix4fv(glGetUniformLocation(progTerrain, "uMVP"),   1, GL_FALSE, glm::value_ptr(VP * modelLeft));
        glDrawElements(GL_TRIANGLES, terrain.indexCount, GL_UNSIGNED_INT, 0);
        glm::mat4 modelFront = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f,-2.0f,-150.0f));
        modelFront = glm::scale(modelFront, glm::vec3(6.0f, 5.0f, 4.0f));
        glUniformMatrix4fv(glGetUniformLocation(progTerrain, "uModel"), 1, GL_FALSE, glm::value_ptr(modelFront));
        glUniformMatrix4fv(glGetUniformLocation(progTerrain, "uMVP"),   1, GL_FALSE, glm::value_ptr(VP * modelFront));
        glDrawElements(GL_TRIANGLES, terrain.indexCount, GL_UNSIGNED_INT, 0);

        glUseProgram(progMountain);
        glUniform1f(glGetUniformLocation(progMountain, "uTime"),       (float)currentTime);
        glUniform3fv(glGetUniformLocation(progMountain, "uSunDir"),    1, glm::value_ptr(sunDir));
        glUniform3fv(glGetUniformLocation(progMountain, "uAmbient"),   1, glm::value_ptr(sc.ambient));
        glUniform1f(glGetUniformLocation(progMountain, "uFogDensity"), fogDensity * 0.5f);
        modelLeft  = glm::translate(glm::mat4(1.0f), glm::vec3(-150.0f,-2.0f,0.0f));
        modelLeft  = glm::scale(modelLeft, glm::vec3(6.0f, 4.0f, 6.0f));
        glUniformMatrix4fv(glGetUniformLocation(progMountain, "uModel"), 1, GL_FALSE, glm::value_ptr(modelLeft));
        glUniformMatrix4fv(glGetUniformLocation(progMountain, "uMVP"),   1, GL_FALSE, glm::value_ptr(VP * modelLeft));
        glBindVertexArray(terrain.VAO);
        glDrawElements(GL_TRIANGLES, terrain.indexCount, GL_UNSIGNED_INT, 0);
        modelFront = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f,-2.0f,-180.0f));
        modelFront = glm::scale(modelFront, glm::vec3(8.0f, 5.0f, 6.0f));
        glUniformMatrix4fv(glGetUniformLocation(progMountain, "uModel"), 1, GL_FALSE, glm::value_ptr(modelFront));
        glUniformMatrix4fv(glGetUniformLocation(progMountain, "uMVP"),   1, GL_FALSE, glm::value_ptr(VP * modelFront));
        glDrawElements(GL_TRIANGLES, terrain.indexCount, GL_UNSIGNED_INT, 0);

        // Water
        glUseProgram(progSky);
        glUniform3f(glGetUniformLocation(progSky, "uColor"), 0.0f, 0.4f, 0.8f);
        glBindVertexArray(waterVAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);

        // Trees
        glUseProgram(progTree);
        glBindVertexArray(forest.VAO);
        glUniformMatrix4fv(glGetUniformLocation(progTree, "uVP"),       1, GL_FALSE, glm::value_ptr(VP));
        glUniform3fv(glGetUniformLocation(progTree, "uSunDir"),   1, glm::value_ptr(sunDir));
        glUniform3fv(glGetUniformLocation(progTree, "uSunColor"), 1, glm::value_ptr(sc.sunColor));
        glUniform3fv(glGetUniformLocation(progTree, "uAmbient"),  1, glm::value_ptr(sc.ambient));
        glUniform3fv(glGetUniformLocation(progTree, "uFogColor"), 1, glm::value_ptr(fogColor));
        glUniform1f(glGetUniformLocation(progTree, "uFogDensity"), fogDensity);
        glUniform3fv(glGetUniformLocation(progTree, "uCamPos"),   1, glm::value_ptr(camPos));
        glUniform1f(glGetUniformLocation(progTree, "uTime"),      (float)currentTime);
        float effectiveWind = manualWind, effectiveWindSpeed = 1.0f;
        if (currentWeather == STORM) { effectiveWind = 4.0f; effectiveWindSpeed = 5.0f; }
        else if (currentWeather == SNOW) { effectiveWind = 1.8f; effectiveWindSpeed = 2.0f; }
        glUniform1f(glGetUniformLocation(progTree, "uWind"),      effectiveWind);
        glUniform1f(glGetUniformLocation(progTree, "uWindSpeed"), effectiveWindSpeed);
        glUniform1f(glGetUniformLocation(progTree, "uSnowFactor"), snowCoverage);
        glDrawArrays(GL_TRIANGLES, 0, forest.vertexCount);

        // Sun disc
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glUseProgram(progSun);
        glm::mat4 sModel = glm::mat4(1.0f);
        sModel = glm::translate(sModel, sunPos);
        sModel = glm::scale(sModel, glm::vec3(25.0f));
        glUniformMatrix4fv(glGetUniformLocation(progSun, "uMVP"), 1, GL_FALSE, glm::value_ptr(VP * sModel));
        glm::vec3 sunColor = (sunPos.y < 50.0f) ? glm::vec3(1.0f,0.5f,0.2f) : glm::vec3(1.0f,0.9f,0.6f);
        glUniform3fv(glGetUniformLocation(progSun, "uColor"), 1, glm::value_ptr(sunColor));
        glBindVertexArray(sunVAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glEnable(GL_DEPTH_TEST);

        // Water surface (dedicated shader)
        glUseProgram(progWater);
        glm::mat4 waterModel = glm::mat4(1.0f);
        glm::mat4 waterMVP   = VP * waterModel;
        glUniformMatrix4fv(glGetUniformLocation(progWater, "uMVP"),    1, GL_FALSE, glm::value_ptr(waterMVP));
        glUniform3fv(glGetUniformLocation(progWater, "uSunDir"),  1, glm::value_ptr(sunDir));
        glUniform1f(glGetUniformLocation(progWater, "uTime"),     (float)glfwGetTime());
        glBindVertexArray(waterVAO);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDrawArrays(GL_TRIANGLES, 0, 6);

        // Particles (rain/snow)
        bool isRaining = weatherCurrent.rain > 0.05f || weatherCurrent.snow > 0.05f;
        if (isRaining) particles.render(progParticle, VP);

        // Plane movement
        if (showPlane) {
            float planeSpeed = 40.0f;
            float leftBound  = -300.0f;
            float rightBound = 150.0f;
            float range      = rightBound - leftBound;
            planePos.x = leftBound + fmod((float)currentTime * planeSpeed, range);
            planePos.y = 28.0f;
            planePos.z = -50.0f;
            planeYaw = 1.57f;
        }

        // Snow coverage update
        if (currentWeather == SNOW) snowCoverage += 0.5f * deltaTime;
        else                        snowCoverage -= 0.3f * deltaTime;
        snowCoverage = glm::clamp(snowCoverage, 0.0f, 1.0f);

        // Night flag
        bool isNight = (timeOfDay < 0.35f || timeOfDay > 0.75f);

        // Aurora
        if (showAurora && isNight) {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            glDepthMask(GL_FALSE);
            glUseProgram(progAurora);
            glUniform1f(glGetUniformLocation(progAurora, "uTime"), (float)currentTime);
            for (int i = 0; i < 3; i++) {
                glUniform1f(glGetUniformLocation(progAurora, "uLayerOffset"), (float)i * 15.0f);
                glUniform1f(glGetUniformLocation(progAurora, "uAlpha"), 0.4f);
                glm::mat4 aModel = glm::mat4(1.0f);
                float x = -200.0f + (i * 30.0f);
                float y = 70.0f  + (i * 10.0f);
                float z = -250.0f + (i * 60.0f);
                aModel = glm::translate(aModel, glm::vec3(x, y, z));
                aModel = glm::rotate(aModel, glm::radians(i * 10.0f), glm::vec3(0, 1, 0));
                aModel = glm::scale(aModel, glm::vec3(800.0f, 100.0f, 1.0f));
                glUniformMatrix4fv(glGetUniformLocation(progAurora, "uMVP"), 1, GL_FALSE, glm::value_ptr(VP * aModel));
                glBindVertexArray(moonVAO);
                glDrawArrays(GL_TRIANGLES, 0, 6);
            }
            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
        }

        // Fireflies
        if (isNight) {
            fireflies.update(dt);
            renderFireflies(VP, timeOfDay, (float)currentTime);
        }

        // Grass
        if (showGrass) {
            glUseProgram(progGrass);
            glUniformMatrix4fv(glGetUniformLocation(progGrass, "uVP"),       1, GL_FALSE, glm::value_ptr(VP));
            glUniform1f(glGetUniformLocation(progGrass, "uTime"),      (float)currentTime);
            glUniform1i(glGetUniformLocation(progGrass, "uIsNight"),   isNight ? 1 : 0);
            glUniform1f(glGetUniformLocation(progGrass, "uWindForce"), manualWind);
            glBindVertexArray(grassVAO);
            glDrawArraysInstanced(GL_TRIANGLES, 0, 3, numGrassBlades);
            glBindVertexArray(0);
        }

        if (showShootingStars) {
            updateAndRenderShootingStars(dt, VP, progShootingStar);
        }

        if (showHotAirBalloons) {
            renderHotAirBalloons((float)currentTime, VP, progBalloon);
        }

        // Scene (birds + plane)
        renderScene(
            progSimple,
            birdMesh,
            planeMesh,
            plane,
            VP,
            timeOfDay,
            (float)currentTime,
            showPlane,
            showBirds
        );

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteProgram(progTerrain);
    glDeleteProgram(progTree);
    glDeleteProgram(progSky);
    glDeleteProgram(progParticle);
    glDeleteProgram(progShootingStar);
    glDeleteProgram(progBalloon);
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
