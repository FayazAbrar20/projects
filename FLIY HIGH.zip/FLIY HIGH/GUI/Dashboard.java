package GUI;
import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;
import javax.swing.event.*;
  
import static javax.swing.JOptionPane.showMessageDialog;
public class Dashboard implements ActionListener{  
    
	 JButton lgnBtn;
     JButton sign;
     JButton exBtn;
     JLabel lusn;
     JLabel lpass;
     JLabel Inum;
     JLabel Inu;
     JTextField uname;
     JTextField upass;
     JTextField unum;
	JFrame frame;
			// JRadioButton p1,p2,p3,p4;
			 JComboBox combo;
			 JComboBox combo1;
			 JComboBox combo2;
			  	String[] cit ={"DHAKA","RAJSHAHI","COX","BARISHAL","SYLHET","JESSORE"};
			  	String[] cit1 ={"DHAKA","RAJSHAHI","COX","BARISHAL","SYLHET","JESSORE"};
			  	String[] day ={"SATURDAY","SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY"};

	
    public Dashboard(){  
	
		
        //create frame
		frame = new JFrame ("BD AIR");
        //construct components
        lgnBtn = new JButton ("Search Flight");
		sign = new JButton(" Logout");
        lusn = new JLabel ("From");
        lpass = new JLabel ("To");
        Inum = new JLabel ("Departing");
       // Inu = new JLabel ("Passenger");
   
		
		/*JRadioButton p1 = new JRadioButton("1");
	   JRadioButton p2 = new JRadioButton("2");
	   JRadioButton p3 = new JRadioButton("3");
	   JRadioButton p4 = new JRadioButton("4");
	   frame.add(p1);
         frame.add(p2);
       frame.add(p3);
       frame.add(p4);
         ButtonGroup bg = new ButtonGroup();
         bg.add(p1);
      bg.add(p2);
              bg.add(p3);
              bg.add(p4);*/

	//JComboBox combo = new JComboBox(cit);
	        combo = new JComboBox<>(cit); // Initialize comboBox
	        combo1 = new JComboBox<>(cit1); // Initialize comboBox
	        combo2 = new JComboBox<>(day); // Initialize comboBox
		frame.add(combo);
		frame.add(combo1);
		frame.add(combo2);

		//addActionListener
		lgnBtn.addActionListener(this);
		sign.addActionListener(this);

        //add components
        frame.add (lgnBtn);
        frame.add (sign);
        frame.add (lusn);
        frame.add (lpass);
        frame.add (Inum);
        //frame.add (Inu);



		 ImageIcon img = new ImageIcon("D:\\FLIY HIGH\\Image\\p3.jpg");
		 frame.setIconImage(img.getImage());
		 

		JLabel background = new JLabel("",img,JLabel.CENTER);
		
        background.setVerticalAlignment(JLabel.CENTER);
		background.setHorizontalAlignment(JLabel.CENTER);

		frame.add(background);
		frame.pack();
        
		
		
		//set component bounds (only needed by Absolute Positioning)
        sign.setBounds (950, 450, 140, 30);
        lgnBtn.setBounds (800, 450, 140, 30);
        lusn.setBounds (800,300, 100, 25);
        lpass.setBounds (800, 350, 100, 25);
		Inum.setBounds (800, 400, 100, 25);
       // Inu.setBounds (800, 450, 100, 25);


        /*
		 p1.setBounds (900, 450, 40, 40);
        p2.setBounds (940, 450, 40, 40);
        p3.setBounds (980, 450, 40, 40);
        p4.setBounds (1020, 450, 40, 40);
		
			    p1.setFocusable(false);
			    p2.setFocusable(false);
			    p3.setFocusable(false);
			   p4.setFocusable(false);//nobox
				p1.setOpaque(false); 		
				p2.setOpaque(false); 		
				p3.setOpaque(false); 		
				p4.setOpaque(false); 	//transparent	
*/

				combo.setBounds(900,300,100,30);
				combo1.setBounds(900,350,100,30);
				combo2.setBounds(900,400,100,30);
						combo.setBackground(Color.WHITE);
						combo1.setBackground(Color.WHITE);
						combo2.setBackground(Color.WHITE);

				
 lgnBtn.setFont(new Font("Montserrat",Font.PLAIN,15));
		lgnBtn.setBackground(Color.decode("#95CADB"));
		lgnBtn.setFocusable(false);
		sign.setFont(new Font("Montserrat",Font.PLAIN,15));
		sign.setBackground(Color.decode("#95CADB"));
	    sign.setFocusable(false);
	
		frame.setLocationRelativeTo(null);//to center screen gui
       // frame.setLayout (null);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane();
	frame.setVisible (true); }
    
	
            public void actionPerformed(ActionEvent e) {
				
					if (combo != null && combo1 != null){
                Object selected = combo.getSelectedItem();
                    String selectedItem = (String) selected;
					
			Object selected1 = combo1.getSelectedItem();

                    String selectedItem1 = (String) selected1;

              if (selectedItem.equals("DHAKA" ) && selectedItem1.equals("RAJSHAHI")){
				  new Dhakatorajshahi();
				  frame.setVisible(false);
				} 
				else if (selectedItem.equals("DHAKA" ) && selectedItem1.equals("COX")){
				  new Dhakatocox();
				  frame.setVisible(false);
				}else if (selectedItem.equals("DHAKA" ) && selectedItem1.equals("JESSORE")){
				  new Dhakatojessore();
				  frame.setVisible(false);
				}else if (selectedItem.equals("DHAKA" ) && selectedItem1.equals("BARISHAL")){
				  new Dhakatobarishal();
				  frame.setVisible(false);
				}else if (selectedItem.equals("DHAKA" ) && selectedItem1.equals("SYLHET")){
				  new Dhakatosylhet();
				  frame.setVisible(false);
				}
					
					else if (selectedItem.equals("RAJSHAHI" ) && selectedItem1.equals("COX")){
				  new Rajshahitocox();
				  frame.setVisible(false);
				}else if (selectedItem.equals("RAJSHAHI" ) && selectedItem1.equals("JESSORE")){
				  new Rajshahitojessore();
				  frame.setVisible(false);
				}else if (selectedItem.equals("RAJSHAHI" ) && selectedItem1.equals("BARISHAL")){
				  new Rajshahitobarishal();
				  frame.setVisible(false);
				}else if (selectedItem.equals("RAJSHAHI" ) && selectedItem1.equals("SYLHET")){
				  new Rajshahitosylhet();
				  frame.setVisible(false);
				}else if (selectedItem.equals("RAJSHAHI" ) && selectedItem1.equals("DHAKA")){
				  new Rajshahitodhaka();
				  frame.setVisible(false);
				}
					else if (selectedItem.equals("SYLHET" ) && selectedItem1.equals("COX")){
				  new Sylhettocox();
				  frame.setVisible(false);
				}else if (selectedItem.equals("SYLHET" ) && selectedItem1.equals("JESSORE")){
				  new Sylhettojessore();
				  frame.setVisible(false);
				}else if (selectedItem.equals("SYLHET" ) && selectedItem1.equals("BARISHAL")){
				  new Sylhettobarishal();
				  frame.setVisible(false);
				}else if (selectedItem.equals("SYLHET" ) && selectedItem1.equals("RAJSHAHI")){
				  new Sylhettorajshahi();
				  frame.setVisible(false);
				}else if (selectedItem.equals("SYLHET" ) && selectedItem1.equals("DHAKA")){
				  new Sylhettodhaka();
				  frame.setVisible(false);
				}
					else if (selectedItem.equals("BARISHAL" ) && selectedItem1.equals("COX")){
				  new Barishaltocox();
				  frame.setVisible(false);
				}else if (selectedItem.equals("BARISHAL" ) && selectedItem1.equals("JESSORE")){
				  new Barishaltojessore();
				  frame.setVisible(false);
				}else if (selectedItem.equals("BARISHAL" ) && selectedItem1.equals("SYLHET")){
				  new Barishaltosylhet();
				  frame.setVisible(false);
				}else if (selectedItem.equals("BARISHAL" ) && selectedItem1.equals("RAJSHAHI")){
				  new Barishaltorajshahi();
				  frame.setVisible(false);
				}else if (selectedItem.equals("BARISHAL" ) && selectedItem1.equals("DHAKA")){
				  new Barishaltodhaka();
				  frame.setVisible(false);
				}
				else if (selectedItem.equals("JESSORE" ) && selectedItem1.equals("COX")){
				  new Jessoretocox();
				  frame.setVisible(false);
				}else if (selectedItem.equals("JESSORE" ) && selectedItem1.equals("BARISHAL")){
				  new Jessoretobarishal();
				  frame.setVisible(false);
				}else if (selectedItem.equals("JESSORE" ) && selectedItem1.equals("SYLHET")){
				  new Jessoretosylhet();
				  frame.setVisible(false);
				}else if (selectedItem.equals("JESSORE" ) && selectedItem1.equals("RAJSHAHI")){
				  new Jessoretorajshahi();
				  frame.setVisible(false);
				}else if (selectedItem.equals("JESSORE" ) && selectedItem1.equals("DHAKA")){
				  new Jessoretodhaka();
				  frame.setVisible(false);
				}
					else if (selectedItem.equals("COX" ) && selectedItem1.equals("JESSORE")){
				  new Coxtojessore();
				  frame.setVisible(false);
				}else if (selectedItem.equals("COX" ) && selectedItem1.equals("BARISHAL")){
				  new Coxtobarishal();
				  frame.setVisible(false);
				}else if (selectedItem.equals("COX" ) && selectedItem1.equals("SYLHET")){
				  new Coxtosylhet();
				  frame.setVisible(false);
				}else if (selectedItem.equals("COX" ) && selectedItem1.equals("RAJSHAHI")){
				  new Coxtorajshahi();
				  frame.setVisible(false);
				}else if (selectedItem.equals("COX" ) && selectedItem1.equals("DHAKA")){
				  new Coxtodhaka();
				  frame.setVisible(false);
				}
				
			else if (e.getSource()  == sign)
			{
					new Login();
					frame.setVisible(false);
}else
			{
					showMessageDialog(null, "Invalid Destination!");
}}
			}}