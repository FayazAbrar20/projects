package GUI;

import GUI.*;
import javax.swing.*;  
import java.awt.event.*;  
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;

import static javax.swing.JOptionPane.showMessageDialog;

public class Coxtorajshahi implements ActionListener {
     JButton a;
     JButton b;
     JButton c;
     JButton d;
     JButton log;
     
	JFrame frame;
	
	
	
    public Coxtorajshahi(){  
	
		
        //create frame
		frame = new JFrame ("BD AIR");
        //construct components
        a = new JButton("COX TO RAJSHAHI : 7:30AM");
		b = new JButton("COX TO RAJSHAHI : 11:30AM");
		c = new JButton("COX TO RAJSHAHI : 3:30PM");
		d = new JButton("COX TO RAJSHAHI : 7:30PM");
		log = new JButton("Logout");
	

        //add components
        frame.add (a);
        frame.add (b);
        frame.add (c);
        frame.add (d);
        frame.add (log);
        
a.addActionListener(this);
b.addActionListener(this);
c.addActionListener(this);
d.addActionListener(this);
log.addActionListener(this);


		 ImageIcon img = new ImageIcon("D:\\FLIY HIGH\\Image\\p3.jpg");
		 frame.setIconImage(img.getImage());

		JLabel background = new JLabel("",img,JLabel.CENTER);
		
        background.setVerticalAlignment(JLabel.CENTER);
		background.setHorizontalAlignment(JLabel.CENTER);

		frame.add(background);
		frame.pack();
        
		
		
		//frame properties
		//adjust size and set layout
        //frame.setSize (624, 400);		//set component bounds (only needed by Absolute Positioning)
        a.setBounds (450, 100, 1000, 150);
        b.setBounds (450, 300, 1000, 150);
        c.setBounds (450,500, 1000, 150);
        d.setBounds (450, 700, 1000, 150);
        log.setBounds (1600, 100, 100,50);
      
			    log.setFocusable(false);
			    a.setFocusable(false);
			    b.setFocusable(false);
			    c.setFocusable(false);
			   d.setFocusable(false);//nobox
				
        a.setFont(new Font("Montserrat",Font.PLAIN,15));
		a.setBackground(Color.decode("#95CADB"));
		b.setFont(new Font("Montserrat",Font.PLAIN,15));
		b.setBackground(Color.decode("#95CADB"));
		c.setFont(new Font("Montserrat",Font.PLAIN,15));
		c.setBackground(Color.decode("#95CADB"));
		d.setFont(new Font("Montserrat",Font.PLAIN,15));
		d.setBackground(Color.decode("#95CADB"));
		log.setFont(new Font("Montserrat",Font.PLAIN,15));
		log.setBackground(Color.decode("#95CADB"));
		
		frame.setLocationRelativeTo(null);//to center screen gui
        frame.setLayout (null);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane();
        frame.setVisible (true); 
}         public void actionPerformed(ActionEvent e) {  
         
         
        if(e.getSource()==a  )
		{
             
         try {
                       File file = new File("D:\\FLIY HIGH\\Txtfiles\\Flight.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                           

                            pw.println("COX TO RAJSHAHI : 7:30AM");
                        
             
                            pw.close();

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }
	
		  new Paymentoptions();
				frame.setVisible(false);
} else if(e.getSource()== b )
		{
             
         try {
                       File file = new File("D:\\FLIY HIGH\\Txtfiles\\Flight.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                           

                            pw.println("COX TO RAJSHAHI : 11:30AM");
                        
             
                            pw.close();

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }
	
	 new Paymentoptions();
				frame.setVisible(false);
}else if(e.getSource()==c  )
		{
             
         try {
                       File file = new File("D:\\FLIY HIGH\\Txtfiles\\Flight.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                           

                            pw.println("COX TO RAJSHAHI : 3:30PM");
                        
             
                            pw.close();

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }
 new Paymentoptions();
				frame.setVisible(false);
} else if(e.getSource()==d )
		{
             
         try {
                      
                       File file = new File("D:\\FLIY HIGH\\Txtfiles\\Flight.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                           

                            pw.println("COX TO RAJSHAHI : 7:30PM");
                        
             
                            pw.close();

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }
	
		 new Paymentoptions();
				frame.setVisible(false);
}	else if(e.getSource()== log)
		{  
			
				
				new Login();
				frame.setVisible(false);
			
            
			
        }  }
	
}