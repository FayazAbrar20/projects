package Entity;

public class Passenger {
    private String name;
    private int age;
    private String contactInformation;

    public Passenger(String name, int age, String contactInformation) {
        this.name = name;
        this.age = age;
        this.contactInformation = contactInformation;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getContactInformation() {
        return contactInformation;
    }

    public void setContactInformation(String contactInformation) {
        this.contactInformation = contactInformation;
    }
}
