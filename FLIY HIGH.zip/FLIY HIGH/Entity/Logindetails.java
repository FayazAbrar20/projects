package Entity;

class Logindetails {
	public Logindetails(){
    private String name;
    private String pass;
    private String number;
    public Logindetails(String name, String pass, String number) {
        this.name = name;
        this.pass = pass;
        this.number = number;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

 
    public String getpass() {
        return pass;
    }


    public String getnumber() {
        return number;
    }

    public void display (){
		System.out.println(name);
		System.out.println(pass);
		System.out.println(number);
}


}}