
import javax.swing.*;  
import java.awt.event.*; 
import GUI.*;

public class Start{
	
	public static void main(String[] args) {  
	 
		 new Login();
		
	} 
}