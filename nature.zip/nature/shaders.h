#ifndef SHADERS_H
#define SHADERS_H

// Terrain shaders
const char* terrainVertexShader = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNorm;
layout (location = 2) in vec2 aUV;

uniform mat4 uMVP;
uniform mat4 uModel;
uniform float uTime;

out vec3 vWorldPos;
out vec3 vNorm;
out vec2 vUV;

void main() {
    vec4 wp = uModel * vec4(aPos, 1.0);
    vWorldPos = wp.xyz;
    vNorm = mat3(uModel) * aNorm;
    vUV = aUV;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
)";

const char* terrainFragmentShader = R"(
#version 330 core
in vec3 vWorldPos;
in vec3 vNorm;
in vec2 vUV;

uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uAmbient;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform vec3 uCamPos;
uniform float uTime;

out vec4 FragColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1, 0));
    float c = hash(i + vec2(0, 1));
    float d = hash(i + vec2(1, 1));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main() {
    vec3 N = normalize(vNorm);
    float h = vWorldPos.y;

    vec3 rock = vec3(0.45, 0.42, 0.38);
    vec3 dirt = vec3(0.38, 0.28, 0.18);
    vec3 grass = vec3(0.22, 0.42, 0.14);
    vec3 snow = vec3(0.92, 0.93, 0.97);

    float nv = noise(vUV * 8.0);
    vec3 col = mix(dirt, grass, smoothstep(-0.5, 0.5, h));
    col = mix(col, rock, smoothstep(2.0, 4.0, h) + (1.0 - N.y) * 0.5);
    col = mix(col, snow, smoothstep(5.0, 8.0, h));
    col *= 0.85 + 0.3 * nv;

    float diff = max(dot(N, normalize(uSunDir)), 0.0);
    float spec = pow(max(dot(reflect(-normalize(uSunDir), N), normalize(uCamPos - vWorldPos)), 0.0), 12.0) * 0.15;

    vec3 lit = uAmbient * col + diff * uSunColor * col + spec * uSunColor;

    float dist = length(vWorldPos - uCamPos);
    float fog = 1.0 - exp(-uFogDensity * dist * 0.015);
    fog = clamp(fog, 0.0, 1.0);

    FragColor = vec4(mix(lit, uFogColor, fog), 1.0);
}
)";

// Tree shaders
const char* treeVertexShader = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNorm;
layout (location = 2) in float aTreeID;

uniform mat4 uVP;
uniform float uTime;
uniform float uWind;

out vec3 vNorm;
out float vHeight;
out float vTreeID;

void main() {
    float phase = aTreeID * 6.283 + uTime * 1.2;
    float sway = sin(phase) * uWind * 0.04 * aPos.y;
    vec3 p = aPos;
    p.x += sway;
    p.z += cos(phase * 0.7) * uWind * 0.02 * aPos.y;

    vNorm = aNorm;
    vHeight = aPos.y;
    vTreeID = aTreeID;
    gl_Position = uVP * vec4(p, 1.0);
}
)";

const char* treeFragmentShader = R"(
#version 330 core
in vec3 vNorm;
in float vHeight;
in float vTreeID;

uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uAmbient;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform vec3 uCamPos;
uniform float uTime;

out vec4 FragColor;

float hash(float n) {
    return fract(sin(n) * 43758.5453);
}

void main() {
    vec3 N = normalize(vNorm);
    float t = hash(vTreeID);

    vec3 leafBase = vec3(0.12 + t * 0.08, 0.35 + t * 0.15, 0.08 + t * 0.06);
    vec3 bark = vec3(0.28, 0.20, 0.13);
    float isBark = step(vHeight, 1.8);
    vec3 col = mix(leafBase, bark, isBark);

    float autumn = smoothstep(0.0, 1.0, sin(uTime * 0.0001 + vTreeID) * 0.5 + 0.5);
    vec3 autumnCol = vec3(0.7 + t * 0.2, 0.3 + t * 0.2, 0.05);
    col = mix(col, autumnCol, autumn * 0.3 * (1.0 - isBark));

    float diff = max(dot(N, normalize(uSunDir)), 0.0) * 0.9;
    vec3 lit = uAmbient * col + diff * uSunColor * col;

    float dist = length(vec3(0.0, vHeight, 0.0) - uCamPos);
    float fog = 1.0 - exp(-uFogDensity * dist * 0.018);

    FragColor = vec4(mix(lit, uFogColor, clamp(fog, 0.0, 1.0)), 1.0);
}
)";

// Sky shaders
const char* skyVertexShader = R"(
#version 330 core
layout (location = 0) in vec2 aPos;

out vec2 vUV;

void main() {
    vUV = aPos * 0.5 + 0.5;
    gl_Position = vec4(aPos, 0.999, 1.0);
}
)";

const char* skyFragmentShader = R"(
#version 330 core
in vec2 vUV;

uniform vec3 uZenith;
uniform vec3 uHorizon;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uTime;
uniform float uClouds;
uniform float uWeather;

out vec4 FragColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x),
               mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

float fbm(vec2 p) {
    return noise(p) * 0.5 + noise(p * 2.0) * 0.25 + noise(p * 4.0) * 0.125;
}

void main() {
    vec2 uv = vUV;
    float elev = uv.y;

    vec3 sky = mix(uHorizon, uZenith, pow(elev, 0.6));

    vec2 cp = vec2(uTime * 0.0002, 0.0);
    float cloud = fbm(uv * 3.0 + cp) * 0.5 + fbm(uv * 6.0 + cp * 2.0) * 0.25;
    float cv = smoothstep(0.3, 0.8, cloud) * uClouds * (1.0 - elev * 0.5);
    vec3 cloudCol = mix(vec3(0.85, 0.88, 0.95) * uSunColor * 2.5,
                        vec3(0.3, 0.3, 0.4), cv * cv);
    sky = mix(sky, cloudCol, cv);

    vec2 sunUV = uv - vec2(0.5 + uSunDir.x * 0.4, 0.2 + uSunDir.y * 0.6);
    float sunD = length(sunUV);
    float sunGlow = exp(-sunD * sunD * 120.0) * 0.9;
    float corona = exp(-sunD * sunD * 8.0) * 0.25;
    sky += uSunColor * sunGlow + uSunColor * corona;

    float stars = step(0.995, hash(floor(uv * 400.0))) * smoothstep(0.4, 0.7, 1.0 - elev) *
                  (1.0 - uClouds) * clamp(1.0 - uSunDir.y * 4.0, 0.0, 1.0);
    sky += vec3(stars * 0.8);

    if (uWeather > 2.5) {
        float lightning = step(0.998, hash(vec2(floor(uTime * 0.1), 7.3))) * step(0.4, elev);
        sky += vec3(lightning * 3.0, lightning * 2.5, lightning);
    }

    FragColor = vec4(sky, 1.0);
}
)";

// Particle shaders (rain/snow)
const char* particleVertexShader = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in float aLife;
layout (location = 2) in float aType;

uniform mat4 uVP;
uniform float uTime;

out float vLife;
out float vType;

void main() {
    vLife = aLife;
    vType = aType;
    gl_Position = uVP * vec4(aPos, 1.0);
    gl_PointSize = mix(2.0, 6.0, aType) * vLife;
}
)";

const char* particleFragmentShader = R"(
#version 330 core
in float vLife;
in float vType;

uniform vec3 uColor;

out vec4 FragColor;

void main() {
    vec2 uv = gl_PointCoord * 2.0 - 1.0;
    float d = dot(uv, uv);
    if (d > 1.0) discard;

    float a = vLife * (1.0 - d * 0.5);
    vec3 c = mix(vec3(0.6, 0.7, 0.9), vec3(0.9, 0.93, 1.0), vType);

    FragColor = vec4(c, a * 0.7);
}
)";

#endif
