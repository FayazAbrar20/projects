package Entity;

public class Booking {
    private String bookingNumber;
    private Passenger passenger;
    private Flight flight;

    public Booking(String bookingNumber, Passenger passenger, Flight flight) {
        this.bookingNumber = bookingNumber;
        this.passenger = passenger;
        this.flight = flight;
    }

    // Getters and setters
    public String getBookingNumber() {
        return bookingNumber;
    }

    public void setBookingNumber(String bookingNumber) {
        this.bookingNumber = bookingNumber;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }
}
