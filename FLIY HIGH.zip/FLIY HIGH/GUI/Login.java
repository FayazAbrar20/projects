package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;

import static javax.swing.JOptionPane.showMessageDialog;
public class Login implements ActionListener{  
    
	 JButton lgnBtn;
     JButton sign;
     JButton exBtn;
     JLabel lusn;
     JLabel lpass;
     JTextField uname;
     JTextField upass;
	JFrame frame;
	
	
	
   public Login(){  
	
		
        //create frame
		frame = new JFrame ("BD AIR");
        //construct components
        lgnBtn = new JButton ("Login");
		sign = new JButton("Register");
        lusn = new JLabel ("Username");
        lpass = new JLabel ("Password");
        uname = new JTextField ();
        upass = new JTextField ();


       
		

		
		//addActionListener
		lgnBtn.addActionListener(this);
		sign.addActionListener(this);

        //add components
        frame.add (lgnBtn);
        frame.add (sign);
        frame.add (lusn);
        frame.add (lpass);
        frame.add (uname);
        frame.add (upass);



		 ImageIcon img = new ImageIcon("D:\\FLIY HIGH\\Image\\p4.jpg");
		 frame.setIconImage(img.getImage());

		JLabel background = new JLabel("",img,JLabel.CENTER);
		
        background.setVerticalAlignment(JLabel.CENTER);
		background.setHorizontalAlignment(JLabel.CENTER);

		frame.add(background);
        
		
		
		//frame properties
		//adjust size and set layout
       // frame.setSize (624, 400);		//set component bounds (only needed by Absolute Positioning)
        lgnBtn.setBounds (800, 500, 100, 30);
        sign.setBounds (950, 500, 100, 30);
        lusn.setBounds (800,400, 100, 25);
        lpass.setBounds (800, 450, 100, 25);
        uname.setBounds (900, 400, 100, 25);
        upass.setBounds (900, 450, 100, 25);
        //background.setBounds (0, 0, 500, 500);
			   		frame.pack();

        lgnBtn.setFont(new Font("Montserrat",Font.PLAIN,15));
		lgnBtn.setBackground(Color.decode("#95CADB"));
		lgnBtn.setFocusable(false);
		sign.setFont(new Font("Comic sans",Font.PLAIN,15));
		sign.setBackground(Color.decode("#95CADB"));
	    sign.setFocusable(false);


		frame.setLocationRelativeTo(null);//to center screen gui
       // frame.setLayout (null);

		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane();
        frame.setVisible (true); 
    }         
    public void actionPerformed(ActionEvent e) {  
         
      if (e.getSource() == lgnBtn) {
           
		 String username = uname.getText();
        String password = upass.getText();
        String fileData = "";
        boolean validCredentials = false;

        try {
            File file = new File("D:\\FLIY HIGH\\Txtfiles\\registration.txt");
            Scanner scanner = new Scanner(file);
             while (scanner.hasNextLine()) {
                fileData += scanner.nextLine() + "\n";
            }

            scanner.close();

            // Check if username and password match any registration data
            if (fileData.contains("Name : " + username) && fileData.contains("pass : " +password)) {
                validCredentials = true;
				
       
        }
            

        } catch (FileNotFoundException ex) {
            System.out.println("File not found: " + ex.getMessage());
        } {if (validCredentials) {
            // Successful login
				new Dashboard();
				frame.setVisible(false);
		}
		else
			{
					showMessageDialog(null, "Invalid Username or password!");
	}
		}}
    	else if(e.getSource()== sign)
		{  
			
				
				new Sign();
				frame.setVisible(false);
			
            
			
	}  	else
			{
					showMessageDialog(null, "Invalid Username or password!");
	}}
	}